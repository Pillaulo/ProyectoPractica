@echo off
chcp 65001 >nul 2>&1
title CuentoMágico — Tests

echo ============================================
echo   CuentoMágico — Ejecutando Tests
echo ============================================
echo.

cd /d "%~dp0..\backend"

if not exist ".venv" (
    echo [ERROR] Entorno virtual no encontrado. Ejecuta scripts\setup.bat primero.
    pause
    exit /b 1
)

call .venv\Scripts\activate.bat

echo Ejecutando tests unitarios + integración...
echo.

python -m pytest tests/ -v

echo.
echo ============================================
if %ERRORLEVEL% equ 0 (
    echo   Todos los tests pasaron
) else (
    echo   Algunos tests fallaron
)
echo ============================================
echo.
pause
