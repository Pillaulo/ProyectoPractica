@echo off
chcp 65001 >nul 2>&1
title CuentoMágico — Setup

echo ============================================
echo   CuentoMágico — Instalación de dependencias
echo ============================================
echo.

REM ── Verificar Python ─────────────────────────
where python >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python no encontrado. Instálalo desde https://python.org
    echo         o ejecuta: winget install Python.Python.3.12
    pause
    exit /b 1
)
echo [OK] Python encontrado
python --version

REM ── Verificar Node.js ────────────────────────
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js no encontrado. Instálalo desde https://nodejs.org
    echo         o ejecuta: winget install OpenJS.NodeJS.LTS
    pause
    exit /b 1
)
echo [OK] Node.js encontrado
node --version
echo.

REM ── Backend ──────────────────────────────────
echo ============================================
echo   Instalando Backend (Python + FastAPI)
echo ============================================
echo.

cd /d "%~dp0..\backend"

if not exist ".venv" (
    echo Creando entorno virtual...
    python -m venv .venv
)

echo Activando entorno virtual...
call .venv\Scripts\activate.bat

echo Instalando dependencias...
pip install -r requirements.txt --quiet
echo.

REM ── Crear .env si no existe ──────────────────
if not exist ".env" (
    echo Creando .env desde .env.example...
    copy .env.example .env >nul
    echo [AVISO] Edita backend\.env y configura tu GROQ_API_KEY
) else (
    echo [OK] backend\.env ya existe
)
echo.

REM ── Frontend ─────────────────────────────────
echo ============================================
echo   Instalando Frontend (React + Vite)
echo ============================================
echo.

cd /d "%~dp0..\frontend"

echo Instalando dependencias npm...
call npm install --silent

REM ── Crear .env si no existe ──────────────────
if not exist ".env" (
    echo Creando .env desde .env.example...
    copy .env.example .env >nul
) else (
    echo [OK] frontend\.env ya existe
)
echo.

REM ── Resultado ────────────────────────────────
echo ============================================
echo   Setup completado
echo ============================================
echo.
echo   Siguiente paso:
echo     1. Edita backend\.env con tu GROQ_API_KEY
echo     2. Ejecuta scripts\dev.bat
echo.
pause
