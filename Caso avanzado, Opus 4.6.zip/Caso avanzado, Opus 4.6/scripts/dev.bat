@echo off
chcp 65001 >nul 2>&1
title CuentoMágico — Dev Launcher

echo ============================================
echo   CuentoMágico — Servidores de desarrollo
echo ============================================
echo.
echo   Backend:  http://localhost:8000
echo   Frontend: http://localhost:5173
echo   API Docs: http://localhost:8000/docs
echo.
echo   Cerrando esta ventana se detienen ambos.
echo ============================================
echo.

REM ── Levantar Backend en ventana separada ─────
start "CuentoMágico Backend" cmd /k "cd /d "%~dp0..\backend" && call .venv\Scripts\activate.bat && uvicorn app.main:app --reload --port 8000"

REM ── Esperar a que el backend arranque ────────
echo Esperando al backend...
timeout /t 3 /nobreak >nul

REM ── Levantar Frontend en ventana separada ────
start "CuentoMágico Frontend" cmd /k "cd /d "%~dp0..\frontend" && npm run dev"

echo.
echo [OK] Ambos servidores iniciados en ventanas separadas.
echo     Cierra las ventanas de cmd para detenerlos.
echo.
pause
