# CuentoMágico — Backend

API REST para generación de cuentos infantiles personalizados con lectura progresiva.

## Stack Tecnológico

| Tecnología | Justificación |
|-----------|---------------|
| **Python 3.11+** | Tipado moderno (`X \| None`, `Protocol`), dataclasses nativas |
| **FastAPI** | Async nativo, validación automática con Pydantic, OpenAPI auto-generado |
| **Pydantic v2** | Schemas de request/response con validación declarativa |
| **SQLAlchemy 2.0** | ORM con soporte declarativo, compatible con SQLite y PostgreSQL |
| **SQLite** | Cero infraestructura para desarrollo; migrable a PostgreSQL cambiando `DATABASE_URL` |
| **Groq SDK** | Cliente oficial para generación de cuentos vía Llama/Mixtral (inferencia ultrarrápida) |
| **pytest** | Framework de testing estándar de Python |

## Arquitectura Hexagonal

```
app/
├── domain/              # Núcleo puro (0 dependencias externas)
│   ├── entities/        #   ReaderProfile, Story, Fragment
│   ├── value_objects/   #   ReadingLevel, Theme, StoryStatus
│   ├── ports/           #   Interfaces (Protocol) para repos y generador
│   ├── services/        #   FragmentationService (lógica de dominio)
│   └── exceptions.py    #   Errores de dominio
│
├── application/         # Casos de uso (orquestación)
│   ├── generate_story.py
│   ├── create_reader_profile.py
│   ├── get_story.py, get_reader_profile.py
│   └── list_*.py, delete_*.py
│
└── infrastructure/      # Adaptadores (mundo exterior)
    ├── http/            #   FastAPI routers + Pydantic schemas
    ├── persistence/     #   SQLAlchemy repos + modelos ORM + stubs in-memory
    └── llm/             #   Adaptador Groq + prompt builder
```

### Flujo de dependencias

```
infraestructura → aplicación → dominio
     (nunca al revés)
```

El dominio **no importa** nada de FastAPI, Pydantic, Groq ni SQLAlchemy.

## Base de Datos

### Esquema

La base de datos tiene 3 tablas:

| Tabla | Descripción |
|-------|-------------|
| `reader_profiles` | Perfiles de lectores infantiles |
| `stories` | Cuentos generados con metadatos |
| `story_fragments` | Fragmentos de lectura progresiva |

Las tablas se crean automáticamente al iniciar el servidor (via `SQLAlchemy.create_all`).
El esquema SQL está documentado en `/docs/schema.sql`.

### Relaciones

```
reader_profiles  1 ──── N  stories  1 ──── N  story_fragments
```

La eliminación es en cascada: borrar un perfil elimina sus cuentos y fragmentos.

### Migración a PostgreSQL

Solo cambiar la variable `DATABASE_URL` en `.env`:

```env
DATABASE_URL=postgresql://user:password@localhost:5432/cuentomagico
```

No se requieren cambios en código.

## Instalación

### Requisitos previos

- Python 3.11 o superior
- pip

### Pasos

```bash
# 1. Crear entorno virtual
cd backend
python -m venv .venv

# 2. Activar entorno virtual
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux/Mac:
source .venv/bin/activate

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Configurar variables de entorno
cp .env.example .env
# Editar .env con tu API key de Groq (https://console.groq.com/keys)
```

## Ejecución

```bash
# Iniciar servidor de desarrollo
uvicorn app.main:app --reload --port 8000

# El servidor estará disponible en http://localhost:8000
# Documentación OpenAPI en http://localhost:8000/docs
```

Al iniciar por primera vez, se crea automáticamente `cuentomagico.db` con todas las tablas.

## Variables de Entorno

| Variable | Obligatoria | Default | Descripción |
|----------|-------------|---------|-------------|
| `GROQ_API_KEY` | Sí | — | API key de Groq |
| `GROQ_MODEL` | No | `llama-3.3-70b-versatile` | Modelo a usar |
| `DATABASE_URL` | No | `sqlite:///./cuentomagico.db` | URL de conexión a la BD |
| `CORS_ORIGINS` | No | `http://localhost:5173` | Orígenes permitidos (separados por coma) |

## Tests

```bash
# Ejecutar todos los tests (unitarios + integración)
pytest -v

# Solo tests unitarios (casos de uso + dominio)
pytest tests/test_generate_story.py -v

# Solo tests de integración (repositorios SQL)
pytest tests/test_integration_repositories.py -v
```

- Los **tests unitarios** usan fakes/stubs: no requieren API key ni base de datos.
- Los **tests de integración** usan SQLite en memoria (`:memory:`): no dejan archivos residuales.

## Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| `GET` | `/health` | Health check |
| `POST` | `/api/profiles` | Crear perfil de lector |
| `GET` | `/api/profiles` | Listar perfiles |
| `GET` | `/api/profiles/{id}` | Obtener perfil |
| `DELETE` | `/api/profiles/{id}` | Eliminar perfil |
| `POST` | `/api/profiles/{id}/stories` | Generar cuento |
| `GET` | `/api/profiles/{id}/stories` | Listar cuentos del perfil |
| `GET` | `/api/stories/{id}` | Obtener cuento completo |
| `GET` | `/api/stories/{id}/fragments` | Obtener fragmentos |
| `DELETE` | `/api/stories/{id}` | Eliminar cuento |
