from __future__ import annotations

from uuid import UUID

from app.domain.entities.story import Story
from app.domain.exceptions import ProfileNotFoundError
from app.domain.ports.reader_profile_repository import ReaderProfileRepository
from app.domain.ports.story_repository import StoryRepository


class ListStoriesByProfileUseCase:
    def __init__(
        self,
        story_repo: StoryRepository,
        profile_repo: ReaderProfileRepository,
    ) -> None:
        self._story_repo = story_repo
        self._profile_repo = profile_repo

    def execute(self, profile_id: UUID) -> list[Story]:
        if self._profile_repo.find_by_id(profile_id) is None:
            raise ProfileNotFoundError(profile_id)
        return self._story_repo.find_by_profile_id(profile_id)
