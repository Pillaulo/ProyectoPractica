from __future__ import annotations

from uuid import UUID

from app.domain.entities.reader_profile import ReaderProfile
from app.domain.exceptions import ProfileNotFoundError
from app.domain.ports.reader_profile_repository import ReaderProfileRepository


class GetReaderProfileUseCase:
    def __init__(self, repo: ReaderProfileRepository) -> None:
        self._repo = repo

    def execute(self, profile_id: UUID) -> ReaderProfile:
        profile = self._repo.find_by_id(profile_id)
        if profile is None:
            raise ProfileNotFoundError(profile_id)
        return profile
