from __future__ import annotations

from uuid import UUID

from app.domain.entities.story import Story
from app.domain.exceptions import StoryNotFoundError
from app.domain.ports.story_repository import StoryRepository


class GetStoryUseCase:
    def __init__(self, repo: StoryRepository) -> None:
        self._repo = repo

    def execute(self, story_id: UUID) -> Story:
        story = self._repo.find_by_id(story_id)
        if story is None:
            raise StoryNotFoundError(story_id)
        return story
