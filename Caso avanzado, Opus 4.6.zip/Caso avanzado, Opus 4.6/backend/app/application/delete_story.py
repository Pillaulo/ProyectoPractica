from __future__ import annotations

from uuid import UUID

from app.domain.exceptions import StoryNotFoundError
from app.domain.ports.story_repository import StoryRepository


class DeleteStoryUseCase:
    def __init__(self, repo: StoryRepository) -> None:
        self._repo = repo

    def execute(self, story_id: UUID) -> None:
        if not self._repo.delete(story_id):
            raise StoryNotFoundError(story_id)
