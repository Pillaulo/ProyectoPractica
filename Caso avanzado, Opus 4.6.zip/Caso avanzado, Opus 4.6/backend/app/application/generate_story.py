from __future__ import annotations

import uuid

from app.domain.entities.fragment import Fragment
from app.domain.entities.story import Story
from app.domain.exceptions import ProfileNotFoundError, StoryGenerationError
from app.domain.ports.reader_profile_repository import ReaderProfileRepository
from app.domain.ports.story_generator import StoryGeneratorPort
from app.domain.ports.story_repository import StoryRepository
from app.domain.services.fragmentation_service import FragmentationService
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme


class GenerateStoryUseCase:
    def __init__(
        self,
        story_repo: StoryRepository,
        profile_repo: ReaderProfileRepository,
        generator: StoryGeneratorPort,
        fragmenter: FragmentationService,
    ) -> None:
        self._story_repo = story_repo
        self._profile_repo = profile_repo
        self._generator = generator
        self._fragmenter = fragmenter

    def execute(
        self,
        profile_id: uuid.UUID,
        theme: Theme,
        custom_prompt: str | None = None,
    ) -> Story:
        profile = self._profile_repo.find_by_id(profile_id)
        if profile is None:
            raise ProfileNotFoundError(profile_id)

        try:
            raw_text = self._generator.generate(
                child_name=profile.name,
                reading_level=profile.reading_level,
                theme=theme,
                custom_prompt=custom_prompt,
            )
        except StoryGenerationError:
            raise
        except Exception as exc:
            raise StoryGenerationError(str(exc)) from exc

        title, body = self._extract_title_and_body(raw_text)
        story_id = uuid.uuid4()

        fragment_texts = self._fragmenter.fragment(body, profile.reading_level)
        fragments = [
            Fragment(story_id=story_id, order=i + 1, content=text)
            for i, text in enumerate(fragment_texts)
        ]

        story = Story(
            id=story_id,
            profile_id=profile_id,
            title=title,
            theme=theme,
            reading_level=profile.reading_level,
            fragments=fragments,
            status=StoryStatus.READY,
        )

        return self._story_repo.save(story)

    @staticmethod
    def _extract_title_and_body(raw_text: str) -> tuple[str, str]:
        """Extrae título (primera línea) y cuerpo del texto generado."""
        lines = raw_text.strip().split("\n", 1)
        if len(lines) == 1:
            first_sentence = raw_text.split(".")[0].strip()
            return first_sentence[:80], raw_text.strip()

        title = lines[0].strip().strip("#").strip()
        body = lines[1].strip()
        return title, body
