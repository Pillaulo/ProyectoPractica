from __future__ import annotations

from app.domain.entities.reader_profile import ReaderProfile
from app.domain.ports.reader_profile_repository import ReaderProfileRepository


class ListReaderProfilesUseCase:
    def __init__(self, repo: ReaderProfileRepository) -> None:
        self._repo = repo

    def execute(self) -> list[ReaderProfile]:
        return self._repo.find_all()
