from __future__ import annotations

from app.domain.entities.reader_profile import ReaderProfile
from app.domain.ports.reader_profile_repository import ReaderProfileRepository
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme


class CreateReaderProfileUseCase:
    def __init__(self, repo: ReaderProfileRepository) -> None:
        self._repo = repo

    def execute(
        self,
        name: str,
        reading_level: ReadingLevel,
        favorite_themes: list[Theme],
    ) -> ReaderProfile:
        profile = ReaderProfile(
            name=name,
            reading_level=reading_level,
            favorite_themes=favorite_themes,
        )
        return self._repo.save(profile)
