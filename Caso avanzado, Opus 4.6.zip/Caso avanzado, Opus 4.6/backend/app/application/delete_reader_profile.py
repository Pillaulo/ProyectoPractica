from __future__ import annotations

from uuid import UUID

from app.domain.exceptions import ProfileNotFoundError
from app.domain.ports.reader_profile_repository import ReaderProfileRepository


class DeleteReaderProfileUseCase:
    def __init__(self, repo: ReaderProfileRepository) -> None:
        self._repo = repo

    def execute(self, profile_id: UUID) -> None:
        if not self._repo.delete(profile_id):
            raise ProfileNotFoundError(profile_id)
