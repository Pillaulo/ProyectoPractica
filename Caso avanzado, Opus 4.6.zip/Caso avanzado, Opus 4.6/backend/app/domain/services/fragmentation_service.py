from __future__ import annotations

import re

from app.domain.value_objects.reading_level import ReadingLevel

_MAX_WORDS: dict[ReadingLevel, int] = {
    ReadingLevel.INITIAL: 40,
    ReadingLevel.BASIC: 70,
    ReadingLevel.INTERMEDIATE: 120,
    ReadingLevel.ADVANCED: 200,
}


class FragmentationService:
    """Divide un texto completo en fragmentos según el nivel lector.

    Es lógica de dominio pura: recibe texto y nivel, retorna lista de strings.
    """

    def fragment(self, full_text: str, level: ReadingLevel) -> list[str]:
        max_words = _MAX_WORDS[level]
        sentences = self._split_sentences(full_text)

        if not sentences:
            return [full_text.strip()] if full_text.strip() else []

        fragments: list[str] = []
        current: list[str] = []
        current_words = 0

        for sentence in sentences:
            words_in_sentence = len(sentence.split())

            if current and current_words + words_in_sentence > max_words:
                fragments.append(" ".join(current))
                current = [sentence]
                current_words = words_in_sentence
            else:
                current.append(sentence)
                current_words += words_in_sentence

        if current:
            fragments.append(" ".join(current))

        return fragments

    @staticmethod
    def _split_sentences(text: str) -> list[str]:
        parts = re.split(r"(?<=[.!?])\s+", text.strip())
        return [s.strip() for s in parts if s.strip()]
