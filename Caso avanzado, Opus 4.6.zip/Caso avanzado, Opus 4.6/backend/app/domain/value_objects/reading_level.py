from enum import Enum


class ReadingLevel(str, Enum):
    INITIAL = "INITIAL"
    BASIC = "BASIC"
    INTERMEDIATE = "INTERMEDIATE"
    ADVANCED = "ADVANCED"
