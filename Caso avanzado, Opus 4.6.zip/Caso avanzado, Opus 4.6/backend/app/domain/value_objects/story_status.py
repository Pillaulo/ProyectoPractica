from enum import Enum


class StoryStatus(str, Enum):
    GENERATING = "GENERATING"
    READY = "READY"
    ERROR = "ERROR"
