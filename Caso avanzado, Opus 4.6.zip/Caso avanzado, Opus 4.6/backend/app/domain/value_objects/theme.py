from enum import Enum


class Theme(str, Enum):
    ANIMALS = "ANIMALS"
    FANTASY = "FANTASY"
    ADVENTURE = "ADVENTURE"
    NATURE = "NATURE"
    SPACE = "SPACE"
    FRIENDSHIP = "FRIENDSHIP"
    HUMOR = "HUMOR"
