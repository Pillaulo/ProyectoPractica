from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme


@dataclass
class ReaderProfile:
    name: str
    reading_level: ReadingLevel
    favorite_themes: list[Theme]
    id: uuid.UUID = field(default_factory=uuid.uuid4)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __post_init__(self) -> None:
        if not self.name or not self.name.strip():
            raise ValueError("El nombre no puede estar vacío")
        if not self.favorite_themes:
            raise ValueError("Debe tener al menos un tema favorito")
