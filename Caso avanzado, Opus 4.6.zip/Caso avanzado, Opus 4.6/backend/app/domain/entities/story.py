from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone

from app.domain.entities.fragment import Fragment
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme


@dataclass
class Story:
    profile_id: uuid.UUID
    title: str
    theme: Theme
    reading_level: ReadingLevel
    fragments: list[Fragment] = field(default_factory=list)
    status: StoryStatus = StoryStatus.GENERATING
    id: uuid.UUID = field(default_factory=uuid.uuid4)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def fragment_count(self) -> int:
        return len(self.fragments)
