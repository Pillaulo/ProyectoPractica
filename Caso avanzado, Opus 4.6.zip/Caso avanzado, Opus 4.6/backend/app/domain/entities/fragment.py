from __future__ import annotations

import uuid
from dataclasses import dataclass, field


@dataclass
class Fragment:
    story_id: uuid.UUID
    order: int
    content: str
    id: uuid.UUID = field(default_factory=uuid.uuid4)
