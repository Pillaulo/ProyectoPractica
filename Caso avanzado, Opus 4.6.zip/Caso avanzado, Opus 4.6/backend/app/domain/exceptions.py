from __future__ import annotations

from uuid import UUID


class DomainError(Exception):
    """Base para todos los errores de dominio."""


class ProfileNotFoundError(DomainError):
    def __init__(self, profile_id: UUID) -> None:
        self.profile_id = profile_id
        super().__init__(f"No se encontró el perfil con ID {profile_id}")


class StoryNotFoundError(DomainError):
    def __init__(self, story_id: UUID) -> None:
        self.story_id = story_id
        super().__init__(f"No se encontró el cuento con ID {story_id}")


class StoryGenerationError(DomainError):
    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Error al generar el cuento: {reason}")
