from __future__ import annotations

from typing import Protocol

from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme


class StoryGeneratorPort(Protocol):
    def generate(
        self,
        child_name: str,
        reading_level: ReadingLevel,
        theme: Theme,
        custom_prompt: str | None = None,
    ) -> str: ...
