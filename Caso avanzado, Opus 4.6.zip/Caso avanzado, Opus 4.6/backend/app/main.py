"""CuentoMágico — Composition Root.

Aquí se ensamblan todas las dependencias y se expone la aplicación FastAPI.
Es el único módulo que conoce todas las capas simultáneamente.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.application.create_reader_profile import CreateReaderProfileUseCase
from app.application.delete_reader_profile import DeleteReaderProfileUseCase
from app.application.delete_story import DeleteStoryUseCase
from app.application.generate_story import GenerateStoryUseCase
from app.application.get_reader_profile import GetReaderProfileUseCase
from app.application.get_story import GetStoryUseCase
from app.application.list_reader_profiles import ListReaderProfilesUseCase
from app.application.list_stories_by_profile import ListStoriesByProfileUseCase
from app.domain.exceptions import DomainError
from app.domain.services.fragmentation_service import FragmentationService
from app.infrastructure.http.error_handler import (
    domain_exception_handler,
    value_error_handler,
)
from app.infrastructure.http.profile_router import create_profile_router
from app.infrastructure.http.story_router import create_story_router
from app.infrastructure.llm.groq_generator import GroqStoryGenerator
from app.infrastructure.persistence.database import create_session_factory
from app.infrastructure.persistence.sql_profile_repository import SqlProfileRepository
from app.infrastructure.persistence.sql_story_repository import SqlStoryRepository

load_dotenv()


def create_app() -> FastAPI:
    app = FastAPI(
        title="CuentoMágico API",
        description="Cuentos personalizados con lectura progresiva para apoyo a lectura infantil",
        version="1.0.0",
    )

    # ── CORS ──────────────────────────────────────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Exception handlers ────────────────────────
    app.add_exception_handler(DomainError, domain_exception_handler)  # type: ignore[arg-type]
    app.add_exception_handler(ValueError, value_error_handler)  # type: ignore[arg-type]

    # ── Infraestructura (adaptadores) ─────────────
    database_url = os.getenv("DATABASE_URL", "sqlite:///./cuentomagico.db")
    session_factory = create_session_factory(database_url)

    profile_repo = SqlProfileRepository(session_factory)
    story_repo = SqlStoryRepository(session_factory)

    groq_api_key = os.getenv("GROQ_API_KEY", "")
    groq_model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
    story_generator = GroqStoryGenerator(api_key=groq_api_key, model=groq_model)

    # ── Dominio (servicios) ───────────────────────
    fragmentation_service = FragmentationService()

    # ── Aplicación (casos de uso) ─────────────────
    create_profile_uc = CreateReaderProfileUseCase(profile_repo)
    get_profile_uc = GetReaderProfileUseCase(profile_repo)
    list_profiles_uc = ListReaderProfilesUseCase(profile_repo)
    delete_profile_uc = DeleteReaderProfileUseCase(profile_repo)

    generate_story_uc = GenerateStoryUseCase(
        story_repo=story_repo,
        profile_repo=profile_repo,
        generator=story_generator,
        fragmenter=fragmentation_service,
    )
    get_story_uc = GetStoryUseCase(story_repo)
    list_stories_uc = ListStoriesByProfileUseCase(story_repo, profile_repo)
    delete_story_uc = DeleteStoryUseCase(story_repo)

    # ── HTTP (routers) ────────────────────────────
    app.include_router(
        create_profile_router(create_profile_uc, get_profile_uc, list_profiles_uc, delete_profile_uc)
    )
    app.include_router(
        create_story_router(generate_story_uc, get_story_uc, list_stories_uc, delete_story_uc)
    )

    # ── Health ────────────────────────────────────
    @app.get("/health", tags=["Health"])
    def health() -> dict:
        return {"status": "ok", "version": "1.0.0"}

    return app


app = create_app()
