from __future__ import annotations

from fastapi import Request
from fastapi.responses import JSONResponse

from app.domain.exceptions import (
    DomainError,
    ProfileNotFoundError,
    StoryGenerationError,
    StoryNotFoundError,
)


async def domain_exception_handler(_request: Request, exc: DomainError) -> JSONResponse:
    if isinstance(exc, (ProfileNotFoundError, StoryNotFoundError)):
        return JSONResponse(
            status_code=404,
            content={"code": "NOT_FOUND", "message": str(exc)},
        )

    if isinstance(exc, StoryGenerationError):
        return JSONResponse(
            status_code=502,
            content={"code": "LLM_ERROR", "message": str(exc)},
        )

    return JSONResponse(
        status_code=500,
        content={"code": "INTERNAL_ERROR", "message": str(exc)},
    )


async def value_error_handler(_request: Request, exc: ValueError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"code": "VALIDATION_ERROR", "message": str(exc)},
    )
