from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter

from app.application.create_reader_profile import CreateReaderProfileUseCase
from app.application.delete_reader_profile import DeleteReaderProfileUseCase
from app.application.get_reader_profile import GetReaderProfileUseCase
from app.application.list_reader_profiles import ListReaderProfilesUseCase
from app.domain.entities.reader_profile import ReaderProfile
from app.infrastructure.http.schemas import CreateProfileRequest, ProfileResponse


def _to_response(profile: ReaderProfile) -> ProfileResponse:
    return ProfileResponse(
        id=profile.id,
        name=profile.name,
        reading_level=profile.reading_level,
        favorite_themes=profile.favorite_themes,
        created_at=profile.created_at,
        updated_at=profile.updated_at,
    )


def create_profile_router(
    create_uc: CreateReaderProfileUseCase,
    get_uc: GetReaderProfileUseCase,
    list_uc: ListReaderProfilesUseCase,
    delete_uc: DeleteReaderProfileUseCase,
) -> APIRouter:
    router = APIRouter(prefix="/api/profiles", tags=["Profiles"])

    @router.post("", response_model=ProfileResponse, status_code=201)
    def create_profile(body: CreateProfileRequest) -> ProfileResponse:
        profile = create_uc.execute(
            name=body.name,
            reading_level=body.reading_level,
            favorite_themes=body.favorite_themes,
        )
        return _to_response(profile)

    @router.get("", response_model=list[ProfileResponse])
    def list_profiles() -> list[ProfileResponse]:
        return [_to_response(p) for p in list_uc.execute()]

    @router.get("/{profile_id}", response_model=ProfileResponse)
    def get_profile(profile_id: UUID) -> ProfileResponse:
        return _to_response(get_uc.execute(profile_id))

    @router.delete("/{profile_id}", status_code=204)
    def delete_profile(profile_id: UUID) -> None:
        delete_uc.execute(profile_id)

    return router
