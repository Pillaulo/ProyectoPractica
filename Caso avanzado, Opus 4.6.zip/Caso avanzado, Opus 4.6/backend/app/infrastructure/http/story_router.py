from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter

from app.application.delete_story import DeleteStoryUseCase
from app.application.generate_story import GenerateStoryUseCase
from app.application.get_story import GetStoryUseCase
from app.application.list_stories_by_profile import ListStoriesByProfileUseCase
from app.domain.entities.story import Story
from app.infrastructure.http.schemas import (
    CreateStoryRequest,
    FragmentResponse,
    FragmentsEnvelope,
    StoryResponse,
    StorySummaryResponse,
)


def _to_story_response(story: Story) -> StoryResponse:
    return StoryResponse(
        id=story.id,
        profile_id=story.profile_id,
        title=story.title,
        theme=story.theme,
        reading_level=story.reading_level,
        status=story.status,
        fragment_count=story.fragment_count,
        fragments=[
            FragmentResponse(id=f.id, order=f.order, content=f.content)
            for f in sorted(story.fragments, key=lambda f: f.order)
        ],
        created_at=story.created_at,
    )


def _to_summary(story: Story) -> StorySummaryResponse:
    return StorySummaryResponse(
        id=story.id,
        profile_id=story.profile_id,
        title=story.title,
        theme=story.theme,
        reading_level=story.reading_level,
        status=story.status,
        fragment_count=story.fragment_count,
        created_at=story.created_at,
    )


def create_story_router(
    generate_uc: GenerateStoryUseCase,
    get_uc: GetStoryUseCase,
    list_uc: ListStoriesByProfileUseCase,
    delete_uc: DeleteStoryUseCase,
) -> APIRouter:
    router = APIRouter(tags=["Stories"])

    @router.post(
        "/api/profiles/{profile_id}/stories",
        response_model=StoryResponse,
        status_code=201,
    )
    def create_story(profile_id: UUID, body: CreateStoryRequest) -> StoryResponse:
        story = generate_uc.execute(
            profile_id=profile_id,
            theme=body.theme,
            custom_prompt=body.custom_prompt,
        )
        return _to_story_response(story)

    @router.get(
        "/api/profiles/{profile_id}/stories",
        response_model=list[StorySummaryResponse],
    )
    def list_stories(profile_id: UUID) -> list[StorySummaryResponse]:
        return [_to_summary(s) for s in list_uc.execute(profile_id)]

    @router.get("/api/stories/{story_id}", response_model=StoryResponse)
    def get_story(story_id: UUID) -> StoryResponse:
        return _to_story_response(get_uc.execute(story_id))

    @router.get("/api/stories/{story_id}/fragments", response_model=FragmentsEnvelope)
    def get_fragments(story_id: UUID) -> FragmentsEnvelope:
        story = get_uc.execute(story_id)
        return FragmentsEnvelope(
            story_id=story.id,
            total_fragments=story.fragment_count,
            fragments=[
                FragmentResponse(id=f.id, order=f.order, content=f.content)
                for f in sorted(story.fragments, key=lambda f: f.order)
            ],
        )

    @router.delete("/api/stories/{story_id}", status_code=204)
    def delete_story(story_id: UUID) -> None:
        delete_uc.execute(story_id)

    return router
