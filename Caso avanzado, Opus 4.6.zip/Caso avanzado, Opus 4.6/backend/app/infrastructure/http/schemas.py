from __future__ import annotations

from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme


# ── Requests ─────────────────────────────────────


class CreateProfileRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    reading_level: ReadingLevel
    favorite_themes: list[Theme] = Field(..., min_length=1)


class CreateStoryRequest(BaseModel):
    theme: Theme
    custom_prompt: str | None = Field(None, max_length=300)


# ── Responses ────────────────────────────────────


class ProfileResponse(BaseModel):
    id: UUID
    name: str
    reading_level: ReadingLevel
    favorite_themes: list[Theme]
    created_at: datetime
    updated_at: datetime


class FragmentResponse(BaseModel):
    id: UUID
    order: int
    content: str


class StorySummaryResponse(BaseModel):
    id: UUID
    profile_id: UUID
    title: str
    theme: Theme
    reading_level: ReadingLevel
    status: StoryStatus
    fragment_count: int
    created_at: datetime


class StoryResponse(BaseModel):
    id: UUID
    profile_id: UUID
    title: str
    theme: Theme
    reading_level: ReadingLevel
    status: StoryStatus
    fragment_count: int
    fragments: list[FragmentResponse]
    created_at: datetime


class FragmentsEnvelope(BaseModel):
    story_id: UUID
    total_fragments: int
    fragments: list[FragmentResponse]


class ErrorResponse(BaseModel):
    code: str
    message: str
    details: dict | None = None
