from __future__ import annotations

from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme

_LEVEL_INSTRUCTIONS: dict[ReadingLevel, str] = {
    ReadingLevel.INITIAL: (
        "Usa frases muy cortas (3-6 palabras). Vocabulario básico. "
        "Mucha repetición. El cuento debe tener entre 100 y 200 palabras."
    ),
    ReadingLevel.BASIC: (
        "Usa frases cortas (6-10 palabras). Vocabulario cotidiano. "
        "Estructura simple. El cuento debe tener entre 200 y 400 palabras."
    ),
    ReadingLevel.INTERMEDIATE: (
        "Usa frases medianas. Vocabulario amplio. "
        "Incluye inicio, nudo y desenlace claros. "
        "El cuento debe tener entre 400 y 600 palabras."
    ),
    ReadingLevel.ADVANCED: (
        "Usa párrafos cortos. Vocabulario rico. "
        "Incluye giros narrativos y personajes desarrollados. "
        "El cuento debe tener entre 600 y 900 palabras."
    ),
}

_THEME_NAMES: dict[Theme, str] = {
    Theme.ANIMALS: "animales",
    Theme.FANTASY: "fantasía",
    Theme.ADVENTURE: "aventuras",
    Theme.NATURE: "naturaleza",
    Theme.SPACE: "espacio",
    Theme.FRIENDSHIP: "amistad",
    Theme.HUMOR: "humor",
}


def build_story_prompt(
    child_name: str,
    level: ReadingLevel,
    theme: Theme,
    custom_prompt: str | None = None,
) -> str:
    theme_name = _THEME_NAMES.get(theme, theme.value.lower())
    level_instruction = _LEVEL_INSTRUCTIONS[level]

    parts = [
        f"Escribe un cuento infantil en español para un niño llamado {child_name}.",
        f"Tema: {theme_name}.",
        f"Nivel de lectura: {level_instruction}",
        (
            "El cuento debe comenzar con el título en la primera línea, "
            "seguido de una línea en blanco, y luego el texto del cuento."
        ),
        "No incluyas marcadores como '##' ni numeración de párrafos.",
    ]

    if custom_prompt:
        parts.append(f"Indicación adicional: {custom_prompt}.")

    return "\n".join(parts)
