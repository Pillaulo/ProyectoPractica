from __future__ import annotations

from groq import Groq

from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme
from app.infrastructure.llm.prompt_builder import build_story_prompt


class GroqStoryGenerator:
    """Adaptador que implementa StoryGeneratorPort usando la API de Groq."""

    def __init__(self, api_key: str, model: str = "llama-3.3-70b-versatile") -> None:
        self._client = Groq(api_key=api_key)
        self._model = model

    def generate(
        self,
        child_name: str,
        reading_level: ReadingLevel,
        theme: Theme,
        custom_prompt: str | None = None,
    ) -> str:
        prompt = build_story_prompt(child_name, reading_level, theme, custom_prompt)

        response = self._client.chat.completions.create(
            model=self._model,
            messages=[
                {
                    "role": "system",
                    "content": "Eres un escritor experto de cuentos infantiles en español.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.8,
            max_tokens=2000,
        )

        content = response.choices[0].message.content
        if not content:
            raise RuntimeError("El LLM devolvió una respuesta vacía")
        return content
