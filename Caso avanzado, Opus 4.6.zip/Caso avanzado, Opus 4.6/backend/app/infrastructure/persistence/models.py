"""Modelos ORM de SQLAlchemy.

Estos modelos pertenecen a la capa de infraestructura. El dominio no los conoce.
La conversión entre modelos ORM y entidades de dominio ocurre en los repositorios.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.infrastructure.persistence.database import Base


class ProfileModel(Base):
    __tablename__ = "reader_profiles"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    reading_level: Mapped[str] = mapped_column(String(20), nullable=False)
    favorite_themes: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    stories: Mapped[list[StoryModel]] = relationship(
        back_populates="profile", cascade="all, delete-orphan"
    )


class StoryModel(Base):
    __tablename__ = "stories"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    profile_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("reader_profiles.id", ondelete="CASCADE"), nullable=False
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    theme: Mapped[str] = mapped_column(String(20), nullable=False)
    reading_level: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="GENERATING")
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )

    profile: Mapped[ProfileModel] = relationship(back_populates="stories")
    fragments: Mapped[list[FragmentModel]] = relationship(
        back_populates="story",
        cascade="all, delete-orphan",
        order_by="FragmentModel.order",
    )


class FragmentModel(Base):
    __tablename__ = "story_fragments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    story_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("stories.id", ondelete="CASCADE"), nullable=False
    )
    order: Mapped[int] = mapped_column(Integer, nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)

    story: Mapped[StoryModel] = relationship(back_populates="fragments")
