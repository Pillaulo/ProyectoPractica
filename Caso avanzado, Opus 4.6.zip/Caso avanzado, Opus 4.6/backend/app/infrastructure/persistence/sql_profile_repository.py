"""Adaptador de persistencia SQL para perfiles de lector.

Implementa el puerto ReaderProfileRepository usando SQLAlchemy.
Convierte entre entidades de dominio y modelos ORM.
"""

from __future__ import annotations

from uuid import UUID

from sqlalchemy.orm import Session, sessionmaker

from app.domain.entities.reader_profile import ReaderProfile
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.theme import Theme
from app.infrastructure.persistence.models import ProfileModel

_THEME_SEP = ","


class SqlProfileRepository:
    def __init__(self, session_factory: sessionmaker[Session]) -> None:
        self._session_factory = session_factory

    def save(self, profile: ReaderProfile) -> ReaderProfile:
        with self._session_factory() as session:
            model = session.get(ProfileModel, str(profile.id))
            if model is None:
                model = self._to_model(profile)
                session.add(model)
            else:
                model.name = profile.name
                model.reading_level = profile.reading_level.value
                model.favorite_themes = _THEME_SEP.join(
                    t.value for t in profile.favorite_themes
                )
                model.updated_at = profile.updated_at
            session.commit()
            session.refresh(model)
            return self._to_entity(model)

    def find_by_id(self, profile_id: UUID) -> ReaderProfile | None:
        with self._session_factory() as session:
            model = session.get(ProfileModel, str(profile_id))
            return self._to_entity(model) if model else None

    def find_all(self) -> list[ReaderProfile]:
        with self._session_factory() as session:
            models = session.query(ProfileModel).order_by(ProfileModel.created_at).all()
            return [self._to_entity(m) for m in models]

    def delete(self, profile_id: UUID) -> bool:
        with self._session_factory() as session:
            model = session.get(ProfileModel, str(profile_id))
            if model is None:
                return False
            session.delete(model)
            session.commit()
            return True

    @staticmethod
    def _to_model(profile: ReaderProfile) -> ProfileModel:
        return ProfileModel(
            id=str(profile.id),
            name=profile.name,
            reading_level=profile.reading_level.value,
            favorite_themes=_THEME_SEP.join(t.value for t in profile.favorite_themes),
            created_at=profile.created_at,
            updated_at=profile.updated_at,
        )

    @staticmethod
    def _to_entity(model: ProfileModel) -> ReaderProfile:
        themes = [Theme(t) for t in model.favorite_themes.split(_THEME_SEP) if t]
        return ReaderProfile(
            id=UUID(model.id),
            name=model.name,
            reading_level=ReadingLevel(model.reading_level),
            favorite_themes=themes,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )
