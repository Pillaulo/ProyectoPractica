from __future__ import annotations

from uuid import UUID

from app.domain.entities.reader_profile import ReaderProfile


class InMemoryProfileRepository:
    """Stub de persistencia en memoria para perfiles de lector."""

    def __init__(self) -> None:
        self._store: dict[UUID, ReaderProfile] = {}

    def save(self, profile: ReaderProfile) -> ReaderProfile:
        self._store[profile.id] = profile
        return profile

    def find_by_id(self, profile_id: UUID) -> ReaderProfile | None:
        return self._store.get(profile_id)

    def find_all(self) -> list[ReaderProfile]:
        return list(self._store.values())

    def delete(self, profile_id: UUID) -> bool:
        return self._store.pop(profile_id, None) is not None
