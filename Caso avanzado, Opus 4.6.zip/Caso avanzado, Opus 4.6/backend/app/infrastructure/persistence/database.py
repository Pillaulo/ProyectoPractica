"""Configuración de SQLAlchemy: engine, session factory y base declarativa."""

from __future__ import annotations

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Base(DeclarativeBase):
    pass


def create_session_factory(database_url: str) -> sessionmaker[Session]:
    connect_args = {}
    if database_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False

    engine = create_engine(database_url, connect_args=connect_args, echo=False)
    Base.metadata.create_all(bind=engine)

    return sessionmaker(bind=engine, autocommit=False, autoflush=False)
