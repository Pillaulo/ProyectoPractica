from __future__ import annotations

from uuid import UUID

from app.domain.entities.story import Story


class InMemoryStoryRepository:
    """Stub de persistencia en memoria para cuentos."""

    def __init__(self) -> None:
        self._store: dict[UUID, Story] = {}

    def save(self, story: Story) -> Story:
        self._store[story.id] = story
        return story

    def find_by_id(self, story_id: UUID) -> Story | None:
        return self._store.get(story_id)

    def find_by_profile_id(self, profile_id: UUID) -> list[Story]:
        return [s for s in self._store.values() if s.profile_id == profile_id]

    def delete(self, story_id: UUID) -> bool:
        return self._store.pop(story_id, None) is not None
