"""Adaptador de persistencia SQL para cuentos y fragmentos.

Implementa el puerto StoryRepository usando SQLAlchemy.
Convierte entre entidades de dominio y modelos ORM.
"""

from __future__ import annotations

from uuid import UUID

from sqlalchemy.orm import Session, joinedload, sessionmaker

from app.domain.entities.fragment import Fragment
from app.domain.entities.story import Story
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme
from app.infrastructure.persistence.models import FragmentModel, StoryModel


class SqlStoryRepository:
    def __init__(self, session_factory: sessionmaker[Session]) -> None:
        self._session_factory = session_factory

    def save(self, story: Story) -> Story:
        with self._session_factory() as session:
            model = (
                session.query(StoryModel)
                .options(joinedload(StoryModel.fragments))
                .filter_by(id=str(story.id))
                .first()
            )

            if model is None:
                model = self._to_model(story)
                session.add(model)
            else:
                model.title = story.title
                model.theme = story.theme.value
                model.reading_level = story.reading_level.value
                model.status = story.status.value

                for frag_model in list(model.fragments):
                    session.delete(frag_model)
                model.fragments = [
                    self._fragment_to_model(f) for f in story.fragments
                ]

            session.commit()
            session.refresh(model)
            return self._to_entity(model)

    def find_by_id(self, story_id: UUID) -> Story | None:
        with self._session_factory() as session:
            model = (
                session.query(StoryModel)
                .options(joinedload(StoryModel.fragments))
                .filter_by(id=str(story_id))
                .first()
            )
            return self._to_entity(model) if model else None

    def find_by_profile_id(self, profile_id: UUID) -> list[Story]:
        with self._session_factory() as session:
            models = (
                session.query(StoryModel)
                .options(joinedload(StoryModel.fragments))
                .filter_by(profile_id=str(profile_id))
                .order_by(StoryModel.created_at.desc())
                .all()
            )
            return [self._to_entity(m) for m in models]

    def delete(self, story_id: UUID) -> bool:
        with self._session_factory() as session:
            model = session.get(StoryModel, str(story_id))
            if model is None:
                return False
            session.delete(model)
            session.commit()
            return True

    @staticmethod
    def _to_model(story: Story) -> StoryModel:
        return StoryModel(
            id=str(story.id),
            profile_id=str(story.profile_id),
            title=story.title,
            theme=story.theme.value,
            reading_level=story.reading_level.value,
            status=story.status.value,
            created_at=story.created_at,
            fragments=[
                FragmentModel(
                    id=str(f.id),
                    story_id=str(story.id),
                    order=f.order,
                    content=f.content,
                )
                for f in story.fragments
            ],
        )

    @staticmethod
    def _fragment_to_model(fragment: Fragment) -> FragmentModel:
        return FragmentModel(
            id=str(fragment.id),
            story_id=str(fragment.story_id),
            order=fragment.order,
            content=fragment.content,
        )

    @staticmethod
    def _to_entity(model: StoryModel) -> Story:
        fragments = [
            Fragment(
                id=UUID(f.id),
                story_id=UUID(f.story_id),
                order=f.order,
                content=f.content,
            )
            for f in sorted(model.fragments, key=lambda f: f.order)
        ]

        return Story(
            id=UUID(model.id),
            profile_id=UUID(model.profile_id),
            title=model.title,
            theme=Theme(model.theme),
            reading_level=ReadingLevel(model.reading_level),
            status=StoryStatus(model.status),
            fragments=fragments,
            created_at=model.created_at,
        )
