"""Tests unitarios para GenerateStoryUseCase.

Usa fakes (stubs) para todas las dependencias externas,
validando que la lógica de negocio funciona correctamente
sin necesidad de LLM real ni base de datos.
"""

from __future__ import annotations

import uuid

import pytest

from app.application.generate_story import GenerateStoryUseCase
from app.domain.entities.reader_profile import ReaderProfile
from app.domain.exceptions import ProfileNotFoundError, StoryGenerationError
from app.domain.services.fragmentation_service import FragmentationService
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme
from app.infrastructure.persistence.in_memory_profile_repository import (
    InMemoryProfileRepository,
)
from app.infrastructure.persistence.in_memory_story_repository import (
    InMemoryStoryRepository,
)


FAKE_STORY_TEXT = (
    "El dragón y la estrella\n\n"
    "Había una vez un dragón llamado Chispa. "
    "Chispa vivía en una montaña muy alta. "
    "Un día vio una estrella que brillaba mucho. "
    "Chispa quería tocar la estrella. "
    "Voló muy alto hasta llegar al cielo. "
    "La estrella le dijo: ¡Hola, dragón! "
    "Chispa se hizo amigo de la estrella. "
    "Desde entonces, cada noche jugaban juntos."
)


class FakeStoryGenerator:
    """Stub que devuelve un texto fijo sin llamar a ningún LLM."""

    def __init__(self, response: str = FAKE_STORY_TEXT) -> None:
        self.response = response
        self.call_count = 0
        self.last_args: dict | None = None

    def generate(
        self,
        child_name: str,
        reading_level: ReadingLevel,
        theme: Theme,
        custom_prompt: str | None = None,
    ) -> str:
        self.call_count += 1
        self.last_args = {
            "child_name": child_name,
            "reading_level": reading_level,
            "theme": theme,
            "custom_prompt": custom_prompt,
        }
        return self.response


class FailingStoryGenerator:
    """Stub que siempre falla al generar."""

    def generate(self, **_kwargs) -> str:  # type: ignore[override]
        raise RuntimeError("Fallo de conexión con el proveedor")


class TestGenerateStoryUseCase:
    def setup_method(self) -> None:
        self.profile_repo = InMemoryProfileRepository()
        self.story_repo = InMemoryStoryRepository()
        self.generator = FakeStoryGenerator()
        self.fragmenter = FragmentationService()
        self.use_case = GenerateStoryUseCase(
            story_repo=self.story_repo,
            profile_repo=self.profile_repo,
            generator=self.generator,
            fragmenter=self.fragmenter,
        )
        self.profile = ReaderProfile(
            name="Sofía",
            reading_level=ReadingLevel.INITIAL,
            favorite_themes=[Theme.FANTASY],
        )
        self.profile_repo.save(self.profile)

    def test_generates_story_with_correct_metadata(self) -> None:
        story = self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.FANTASY,
        )
        assert story.title == "El dragón y la estrella"
        assert story.status == StoryStatus.READY
        assert story.profile_id == self.profile.id
        assert story.theme == Theme.FANTASY
        assert story.reading_level == ReadingLevel.INITIAL

    def test_story_has_fragments(self) -> None:
        story = self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.FANTASY,
        )
        assert story.fragment_count >= 1
        assert len(story.fragments) == story.fragment_count

    def test_fragments_are_ordered_sequentially(self) -> None:
        story = self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.ADVENTURE,
        )
        orders = [f.order for f in story.fragments]
        assert orders == list(range(1, len(orders) + 1))

    def test_all_fragments_belong_to_story(self) -> None:
        story = self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.ANIMALS,
        )
        for fragment in story.fragments:
            assert fragment.story_id == story.id

    def test_story_is_persisted(self) -> None:
        story = self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.ANIMALS,
        )
        stored = self.story_repo.find_by_id(story.id)
        assert stored is not None
        assert stored.id == story.id
        assert stored.fragment_count == story.fragment_count

    def test_generator_receives_profile_data(self) -> None:
        self.use_case.execute(
            profile_id=self.profile.id,
            theme=Theme.SPACE,
            custom_prompt="con un cohete rojo",
        )
        assert self.generator.call_count == 1
        assert self.generator.last_args is not None
        assert self.generator.last_args["child_name"] == "Sofía"
        assert self.generator.last_args["reading_level"] == ReadingLevel.INITIAL
        assert self.generator.last_args["theme"] == Theme.SPACE
        assert self.generator.last_args["custom_prompt"] == "con un cohete rojo"

    def test_raises_on_missing_profile(self) -> None:
        fake_id = uuid.uuid4()
        with pytest.raises(ProfileNotFoundError):
            self.use_case.execute(profile_id=fake_id, theme=Theme.FANTASY)

    def test_raises_story_generation_error_on_llm_failure(self) -> None:
        failing_uc = GenerateStoryUseCase(
            story_repo=self.story_repo,
            profile_repo=self.profile_repo,
            generator=FailingStoryGenerator(),  # type: ignore[arg-type]
            fragmenter=self.fragmenter,
        )
        with pytest.raises(StoryGenerationError):
            failing_uc.execute(profile_id=self.profile.id, theme=Theme.HUMOR)


class TestFragmentationService:
    """Tests del servicio de dominio de fragmentación."""

    def setup_method(self) -> None:
        self.service = FragmentationService()

    def test_initial_level_creates_short_fragments(self) -> None:
        text = (
            "El gato pequeño duerme en su cama. El gato pequeño come su comida favorita. "
            "El gato pequeño juega con una pelota roja. El gato pequeño corre por el jardín. "
            "El gato pequeño salta muy alto. El gato pequeño ríe con sus amigos. "
            "El gato pequeño vuela en sus sueños bonitos. El gato pequeño nada en el río azul. "
            "El gato pequeño baila bajo la lluvia fresca. El gato pequeño canta una canción alegre. "
            "El gato pequeño sueña con aventuras nuevas. El gato pequeño vive muy feliz cada día."
        )
        fragments = self.service.fragment(text, ReadingLevel.INITIAL)
        assert len(fragments) >= 2
        for frag in fragments:
            assert len(frag.split()) <= 50

    def test_advanced_level_creates_fewer_fragments(self) -> None:
        text = (
            "Había una vez un explorador valiente que recorría tierras lejanas. "
            "Un día encontró un mapa misterioso en una cueva oscura. "
            "El mapa señalaba un tesoro escondido en la cima de una montaña. "
            "Decidió emprender el viaje sin importar los peligros."
        )
        initial_frags = self.service.fragment(text, ReadingLevel.INITIAL)
        advanced_frags = self.service.fragment(text, ReadingLevel.ADVANCED)
        assert len(advanced_frags) <= len(initial_frags)

    def test_empty_text_returns_empty_list(self) -> None:
        assert self.service.fragment("", ReadingLevel.BASIC) == []

    def test_single_sentence(self) -> None:
        fragments = self.service.fragment("Hola mundo.", ReadingLevel.INITIAL)
        assert len(fragments) == 1
        assert fragments[0] == "Hola mundo."
