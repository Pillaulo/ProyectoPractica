"""Tests de integración para los repositorios SQL.

Usan SQLite en memoria (:memory:) para validar que la persistencia
real funciona correctamente sin necesidad de un servidor de base de datos.
"""

from __future__ import annotations

import uuid

import pytest

from app.domain.entities.fragment import Fragment
from app.domain.entities.reader_profile import ReaderProfile
from app.domain.entities.story import Story
from app.domain.value_objects.reading_level import ReadingLevel
from app.domain.value_objects.story_status import StoryStatus
from app.domain.value_objects.theme import Theme
from app.infrastructure.persistence.database import create_session_factory
from app.infrastructure.persistence.sql_profile_repository import SqlProfileRepository
from app.infrastructure.persistence.sql_story_repository import SqlStoryRepository


@pytest.fixture()
def session_factory():
    return create_session_factory("sqlite:///:memory:")


@pytest.fixture()
def profile_repo(session_factory):
    return SqlProfileRepository(session_factory)


@pytest.fixture()
def story_repo(session_factory):
    return SqlStoryRepository(session_factory)


def _make_profile(**overrides) -> ReaderProfile:
    defaults = {
        "name": "Sofía",
        "reading_level": ReadingLevel.INITIAL,
        "favorite_themes": [Theme.FANTASY, Theme.ANIMALS],
    }
    defaults.update(overrides)
    return ReaderProfile(**defaults)


def _make_story(profile_id: uuid.UUID, **overrides) -> Story:
    story_id = overrides.pop("id", uuid.uuid4())
    defaults = {
        "id": story_id,
        "profile_id": profile_id,
        "title": "El dragón valiente",
        "theme": Theme.FANTASY,
        "reading_level": ReadingLevel.INITIAL,
        "status": StoryStatus.READY,
        "fragments": [
            Fragment(story_id=story_id, order=1, content="Había una vez un dragón."),
            Fragment(story_id=story_id, order=2, content="El dragón vivía en una montaña."),
            Fragment(story_id=story_id, order=3, content="Un día decidió volar muy alto."),
        ],
    }
    defaults.update(overrides)
    return Story(**defaults)


# ── ProfileRepository ─────────────────────────────


class TestSqlProfileRepository:
    def test_save_and_find_by_id(self, profile_repo) -> None:
        profile = _make_profile()
        saved = profile_repo.save(profile)

        found = profile_repo.find_by_id(saved.id)
        assert found is not None
        assert found.id == profile.id
        assert found.name == "Sofía"
        assert found.reading_level == ReadingLevel.INITIAL
        assert found.favorite_themes == [Theme.FANTASY, Theme.ANIMALS]

    def test_find_by_id_returns_none_for_missing(self, profile_repo) -> None:
        assert profile_repo.find_by_id(uuid.uuid4()) is None

    def test_find_all(self, profile_repo) -> None:
        profile_repo.save(_make_profile(name="Ana"))
        profile_repo.save(_make_profile(name="Luis"))

        all_profiles = profile_repo.find_all()
        assert len(all_profiles) == 2
        names = {p.name for p in all_profiles}
        assert names == {"Ana", "Luis"}

    def test_delete(self, profile_repo) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        assert profile_repo.delete(profile.id) is True
        assert profile_repo.find_by_id(profile.id) is None

    def test_delete_nonexistent_returns_false(self, profile_repo) -> None:
        assert profile_repo.delete(uuid.uuid4()) is False

    def test_save_updates_existing(self, profile_repo) -> None:
        profile = _make_profile(name="Ana")
        profile_repo.save(profile)

        profile.name = "Ana María"
        profile.reading_level = ReadingLevel.ADVANCED
        profile_repo.save(profile)

        found = profile_repo.find_by_id(profile.id)
        assert found is not None
        assert found.name == "Ana María"
        assert found.reading_level == ReadingLevel.ADVANCED


# ── StoryRepository ───────────────────────────────


class TestSqlStoryRepository:
    def test_save_and_find_by_id(self, profile_repo, story_repo) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        story = _make_story(profile.id)
        saved = story_repo.save(story)

        found = story_repo.find_by_id(saved.id)
        assert found is not None
        assert found.id == story.id
        assert found.title == "El dragón valiente"
        assert found.theme == Theme.FANTASY
        assert found.status == StoryStatus.READY

    def test_fragments_are_persisted_and_ordered(self, profile_repo, story_repo) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        story = _make_story(profile.id)
        story_repo.save(story)

        found = story_repo.find_by_id(story.id)
        assert found is not None
        assert found.fragment_count == 3
        assert found.fragments[0].order == 1
        assert found.fragments[1].order == 2
        assert found.fragments[2].order == 3
        assert found.fragments[0].content == "Había una vez un dragón."

    def test_find_by_profile_id(self, profile_repo, story_repo) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        story_repo.save(_make_story(profile.id, title="Cuento 1"))
        story_repo.save(_make_story(profile.id, title="Cuento 2"))

        stories = story_repo.find_by_profile_id(profile.id)
        assert len(stories) == 2
        titles = {s.title for s in stories}
        assert titles == {"Cuento 1", "Cuento 2"}

    def test_find_by_profile_id_returns_empty_for_other_profile(
        self, profile_repo, story_repo
    ) -> None:
        profile = _make_profile()
        profile_repo.save(profile)
        story_repo.save(_make_story(profile.id))

        other_id = uuid.uuid4()
        assert story_repo.find_by_profile_id(other_id) == []

    def test_delete(self, profile_repo, story_repo) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        story = _make_story(profile.id)
        story_repo.save(story)

        assert story_repo.delete(story.id) is True
        assert story_repo.find_by_id(story.id) is None

    def test_delete_nonexistent_returns_false(self, story_repo) -> None:
        assert story_repo.delete(uuid.uuid4()) is False

    def test_cascade_delete_profile_removes_stories(
        self, profile_repo, story_repo
    ) -> None:
        profile = _make_profile()
        profile_repo.save(profile)

        story = _make_story(profile.id)
        story_repo.save(story)

        profile_repo.delete(profile.id)
        assert story_repo.find_by_id(story.id) is None

    def test_data_survives_across_sessions(self, session_factory) -> None:
        """Simula un reinicio creando nuevos repos con la misma session factory."""
        repo1 = SqlProfileRepository(session_factory)
        story_repo1 = SqlStoryRepository(session_factory)

        profile = _make_profile()
        repo1.save(profile)
        story = _make_story(profile.id)
        story_repo1.save(story)

        repo2 = SqlProfileRepository(session_factory)
        story_repo2 = SqlStoryRepository(session_factory)

        found_profile = repo2.find_by_id(profile.id)
        found_story = story_repo2.find_by_id(story.id)

        assert found_profile is not None
        assert found_story is not None
        assert found_story.fragment_count == 3
