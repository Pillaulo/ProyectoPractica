# CuentoMágico

Aplicación web de cuentos infantiles personalizados con lectura progresiva, generados por IA.

## Puesta en marcha (5 pasos)

### 1. Requisitos previos

- **Python 3.11+** — [python.org](https://python.org) o `winget install Python.Python.3.12`
- **Node.js 20+** — [nodejs.org](https://nodejs.org) o `winget install OpenJS.NodeJS.LTS`

### 2. Instalar dependencias

```bat
scripts\setup.bat
```

### 3. Configurar API key

Editar `backend\.env` y poner tu API key de Groq ([console.groq.com/keys](https://console.groq.com/keys)):

```
GROQ_API_KEY=gsk_tu-api-key-aqui
```

### 4. Levantar servidores

```bat
scripts\dev.bat
```

### 5. Abrir la aplicación

Ir a **http://localhost:5173** en el navegador.

---

## Scripts disponibles

| Script | Descripción |
|--------|-------------|
| `scripts\setup.bat` | Instala dependencias de backend y frontend |
| `scripts\dev.bat` | Levanta backend (:8000) y frontend (:5173) |
| `scripts\test.bat` | Ejecuta todos los tests del backend |

## Estructura del proyecto

```
CuentoMágico/
├── backend/           # API REST — Python + FastAPI + SQLAlchemy
│   ├── app/
│   │   ├── domain/          # Entidades, puertos, servicios (puro)
│   │   ├── application/     # Casos de uso
│   │   └── infrastructure/  # Adaptadores (HTTP, DB, LLM)
│   └── tests/
├── frontend/          # SPA — React + TypeScript + Vite + Tailwind
│   └── src/
│       ├── pages/           # HomePage, ProfilePage, ReaderPage
│       ├── components/      # Layout, Loading, Error, Progress
│       └── api/             # Cliente HTTP
├── docs/              # PRD, Arquitectura, ADRs, OpenAPI, Schema
└── scripts/           # setup.bat, dev.bat, test.bat
```

## Documentación

- [PRD](docs/PRD.md) — Requisitos del producto
- [Arquitectura](docs/ARCHITECTURE.md) — Diseño hexagonal
- [Contrato API](docs/openapi.yaml) — OpenAPI 3.0
- [Benchmark](docs/BENCHMARK.md) — Criterios de evaluación
- [ADRs](docs/ADR-001.md) — Decisiones arquitectónicas
