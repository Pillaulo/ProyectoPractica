-- ============================================
-- CuentoMágico — Esquema de Base de Datos
-- Motor: SQLite (compatible con PostgreSQL)
-- ============================================

-- Perfiles de lectores infantiles
CREATE TABLE IF NOT EXISTS reader_profiles (
    id          TEXT PRIMARY KEY,               -- UUID v4 como string
    name        TEXT NOT NULL,                  -- Nombre del niño (máx 100 chars)
    reading_level TEXT NOT NULL,                -- INITIAL | BASIC | INTERMEDIATE | ADVANCED
    favorite_themes TEXT NOT NULL,              -- Temas separados por coma: "FANTASY,ANIMALS"
    created_at  DATETIME NOT NULL DEFAULT (datetime('now')),
    updated_at  DATETIME NOT NULL DEFAULT (datetime('now'))
);

-- Cuentos generados
CREATE TABLE IF NOT EXISTS stories (
    id            TEXT PRIMARY KEY,             -- UUID v4 como string
    profile_id    TEXT NOT NULL,                -- FK a reader_profiles
    title         TEXT NOT NULL,                -- Título del cuento
    theme         TEXT NOT NULL,                -- ANIMALS | FANTASY | ADVENTURE | ...
    reading_level TEXT NOT NULL,                -- Nivel con el que se generó
    status        TEXT NOT NULL DEFAULT 'GENERATING',  -- GENERATING | READY | ERROR
    created_at    DATETIME NOT NULL DEFAULT (datetime('now')),

    FOREIGN KEY (profile_id) REFERENCES reader_profiles(id) ON DELETE CASCADE
);

-- Fragmentos de lectura progresiva
CREATE TABLE IF NOT EXISTS story_fragments (
    id        TEXT PRIMARY KEY,                 -- UUID v4 como string
    story_id  TEXT NOT NULL,                    -- FK a stories
    "order"   INTEGER NOT NULL,                -- Posición en el cuento (1-indexed)
    content   TEXT NOT NULL,                    -- Texto del fragmento

    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE
);

-- ── Índices ──────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_stories_profile_id
    ON stories(profile_id);

CREATE INDEX IF NOT EXISTS idx_fragments_story_id
    ON story_fragments(story_id);

CREATE INDEX IF NOT EXISTS idx_fragments_order
    ON story_fragments(story_id, "order");
