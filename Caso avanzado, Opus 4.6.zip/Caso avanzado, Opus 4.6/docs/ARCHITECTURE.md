# CuentoMágico — Arquitectura Hexagonal del Backend

## Visión General

El backend sigue una **arquitectura hexagonal** (puertos y adaptadores) que aísla la lógica de negocio de toda infraestructura externa. El dominio es el núcleo y no depende de frameworks, bases de datos ni proveedores de IA.

## Diagrama de Componentes

```mermaid
graph TB
    subgraph Frontend["Frontend (React)"]
        UI[UI Components]
    end

    subgraph Infrastructure["Infraestructura"]
        subgraph HTTP["Adaptador HTTP"]
            PR[profile_router.py]
            SR[story_router.py]
            SCH[schemas.py - DTOs Pydantic]
            EH[error_handler.py]
        end

        subgraph Persistence["Adaptador Persistencia"]
            SPR[SqlProfileRepository]
            SSR[SqlStoryRepository]
            MOD[models.py - ORM Models]
            DB[(SQLite / PostgreSQL)]
        end

        subgraph LLM["Adaptador LLM"]
            GG[GroqStoryGenerator]
            PB[prompt_builder.py]
            GAPI[Groq API]
        end
    end

    subgraph Application["Aplicación (Casos de Uso)"]
        CRP[CreateReaderProfile]
        GS[GenerateStory]
        GSt[GetStory]
        LS[ListStoriesByProfile]
        GRP[GetReaderProfile]
        LRP[ListReaderProfiles]
        DRP[DeleteReaderProfile]
        DS[DeleteStory]
    end

    subgraph Domain["Dominio (Núcleo Puro)"]
        subgraph Entities["Entidades"]
            RP[ReaderProfile]
            ST[Story]
            FR[Fragment]
        end

        subgraph ValueObjects["Value Objects"]
            RL[ReadingLevel]
            TH[Theme]
            SS[StoryStatus]
        end

        subgraph Ports["Puertos (Interfaces)"]
            RPR[ReaderProfileRepository]
            SRP[StoryRepository]
            SGP[StoryGeneratorPort]
        end

        subgraph Services["Servicios de Dominio"]
            FS[FragmentationService]
        end

        EX[exceptions.py]
    end

    UI -->|HTTP REST| PR
    UI -->|HTTP REST| SR
    PR --> CRP & GRP & LRP & DRP
    SR --> GS & GSt & LS & DS
    CRP & GRP & LRP & DRP --> RPR
    GS --> SRP & RPR & SGP
    GS --> FS
    GSt & LS & DS --> SRP
    SPR -.->|implementa| RPR
    SSR -.->|implementa| SRP
    GG -.->|implementa| SGP
    SPR --> DB
    SSR --> DB
    GG --> GAPI

    style Domain fill:#e8f5e9,stroke:#2e7d32,stroke-width:2px
    style Application fill:#e3f2fd,stroke:#1565c0,stroke-width:2px
    style Infrastructure fill:#fff3e0,stroke:#e65100,stroke-width:2px
```

## Capas

### Dominio (Núcleo Puro)

El dominio **no importa** nada de FastAPI, Pydantic, SQLAlchemy ni Groq.

#### Entidades

| Entidad | Campos | Validación |
|---------|--------|------------|
| `ReaderProfile` | `id`, `name`, `reading_level`, `favorite_themes`, `created_at`, `updated_at` | Nombre no vacío, al menos 1 tema |
| `Story` | `id`, `profile_id`, `title`, `theme`, `reading_level`, `fragments`, `status`, `created_at` | Propiedad `fragment_count` |
| `Fragment` | `id`, `story_id`, `order`, `content` | — |

#### Value Objects (Enums)

| Value Object | Valores |
|-------------|---------|
| `ReadingLevel` | `INITIAL`, `BASIC`, `INTERMEDIATE`, `ADVANCED` |
| `Theme` | `ANIMALS`, `FANTASY`, `ADVENTURE`, `NATURE`, `SPACE`, `FRIENDSHIP`, `HUMOR` |
| `StoryStatus` | `GENERATING`, `READY`, `ERROR` |

#### Puertos (Interfaces como `Protocol`)

| Puerto | Métodos |
|--------|---------|
| `ReaderProfileRepository` | `save`, `find_by_id`, `find_all`, `delete` |
| `StoryRepository` | `save`, `find_by_id`, `find_by_profile_id`, `delete` |
| `StoryGeneratorPort` | `generate(child_name, reading_level, theme, custom_prompt?) → str` |

El `StoryGeneratorPort` recibe parámetros de dominio (no un prompt raw) para mantener la pureza del dominio. La construcción del prompt se hace en el adaptador de infraestructura (ver ADR-005).

#### Servicio de Dominio

`FragmentationService`: divide texto completo en fragmentos según el nivel de lectura. Es lógica pura — no tiene dependencias externas.

| Nivel | Máx. palabras/fragmento |
|-------|------------------------|
| INITIAL | 40 |
| BASIC | 70 |
| INTERMEDIATE | 120 |
| ADVANCED | 200 |

### Aplicación (Casos de Uso)

| Caso de Uso | Responsabilidad |
|-------------|-----------------|
| `CreateReaderProfile` | Crea y persiste un perfil de lector |
| `GetReaderProfile` | Obtiene un perfil por ID |
| `ListReaderProfiles` | Lista todos los perfiles |
| `DeleteReaderProfile` | Elimina perfil y sus datos asociados |
| `GenerateStory` | Orquesta generación LLM + fragmentación + persistencia |
| `GetStory` | Obtiene un cuento completo con fragmentos |
| `ListStoriesByProfile` | Lista cuentos de un perfil |
| `DeleteStory` | Elimina un cuento |

### Infraestructura (Adaptadores)

| Adaptador | Implementa | Tecnología |
|-----------|-----------|------------|
| `profile_router.py` / `story_router.py` | Entrada HTTP | FastAPI |
| `schemas.py` | DTOs de request/response | Pydantic v2 |
| `SqlProfileRepository` | `ReaderProfileRepository` | SQLAlchemy 2.0 |
| `SqlStoryRepository` | `StoryRepository` | SQLAlchemy 2.0 |
| `GroqStoryGenerator` | `StoryGeneratorPort` | Groq SDK |
| `prompt_builder.py` | Construcción de prompts | Puro Python |

## Diagrama de Secuencia — Crear Cuento

```mermaid
sequenceDiagram
    actor User as Frontend
    participant Router as StoryRouter
    participant UC as GenerateStoryUseCase
    participant PRepo as ProfileRepository
    participant Gen as StoryGeneratorPort
    participant Frag as FragmentationService
    participant SRepo as StoryRepository

    User->>+Router: POST /api/profiles/{id}/stories
    Router->>Router: Validar request (Pydantic)
    Router->>+UC: execute(profile_id, theme, custom_prompt?)

    UC->>+PRepo: find_by_id(profile_id)
    PRepo-->>-UC: ReaderProfile
    Note over UC: Si no existe → ProfileNotFoundError

    UC->>+Gen: generate(child_name, reading_level, theme, custom_prompt?)
    Note over Gen: Construye prompt internamente
    Gen->>Gen: Llama Groq API
    Gen-->>-UC: raw_text (string)

    UC->>UC: _extract_title_and_body(raw_text)
    UC->>+Frag: fragment(body, reading_level)
    Frag-->>-UC: list[str]

    UC->>UC: Crear entidades Story + Fragments
    UC->>+SRepo: save(story)
    SRepo-->>-UC: Story (persistido)

    UC-->>-Router: Story
    Router->>Router: Mapear a StoryResponse (DTO)
    Router-->>-User: 201 Created + JSON
```

## Diagrama Entidad-Relación

```mermaid
erDiagram
    READER_PROFILES {
        text id PK "UUID"
        text name "max 100 chars"
        text reading_level "INITIAL|BASIC|INTERMEDIATE|ADVANCED"
        text favorite_themes "comma-separated"
        datetime created_at
        datetime updated_at
    }

    STORIES {
        text id PK "UUID"
        text profile_id FK "→ reader_profiles"
        text title
        text theme "ANIMALS|FANTASY|..."
        text reading_level
        text status "GENERATING|READY|ERROR"
        datetime created_at
    }

    STORY_FRAGMENTS {
        text id PK "UUID"
        text story_id FK "→ stories"
        integer order "1-indexed"
        text content
    }

    READER_PROFILES ||--o{ STORIES : "genera"
    STORIES ||--o{ STORY_FRAGMENTS : "contiene"
```

## Flujo de Dependencias

```
infraestructura → aplicación → dominio
     (nunca al revés)
```

La inyección de dependencias se hace en `main.py` (composition root) siguiendo ADR-004.

## ADRs Relacionados

| ADR | Decisión |
|-----|----------|
| [ADR-001](ADR-001.md) | Arquitectura hexagonal sobre MVC |
| [ADR-002](ADR-002.md) | FragmentationService como servicio de dominio puro |
| [ADR-003](ADR-003.md) | SQLite para desarrollo, PostgreSQL para producción |
| [ADR-004](ADR-004.md) | Inyección de dependencias manual en composition root |
| [ADR-005](ADR-005.md) | Construcción de prompts en la capa de infraestructura |
