# CuentoMágico — Product Requirements Document (PRD)

## 1. Descripción del Problema

En América Latina, el 53% de los niños de 10 años no puede comprender un texto simple (UNESCO, 2022). Las herramientas de lectura existentes son genéricas: no se adaptan al nivel del niño ni a sus intereses. Esto genera frustración y abandono temprano del hábito lector.

**CuentoMágico** resuelve esto generando cuentos personalizados con IA, adaptados al nivel lector del niño y fragmentados en secciones de lectura progresiva. Cada cuento usa el nombre del niño, sus temas favoritos y un vocabulario apropiado para su nivel.

## 2. Usuarios Objetivo

| Tipo | Descripción | Necesidad principal |
|------|-------------|---------------------|
| **Niño lector** (4-10 años) | Lectores en formación con distintos niveles | Cuentos atractivos que pueda leer a su ritmo |
| **Padre/tutor** | Acompaña al niño en el proceso | Herramienta simple y segura para motivar la lectura |
| **Educador** | Usa la herramienta como apoyo pedagógico | Contenido adaptado al nivel de cada estudiante |

### Niveles de lectura soportados

| Nivel | Edad aprox. | Características |
|-------|-------------|-----------------|
| `INITIAL` | 4-5 años | Oraciones muy cortas, vocabulario básico, fragmentos de ~40 palabras |
| `BASIC` | 5-6 años | Oraciones simples, algo más de vocabulario, fragmentos de ~70 palabras |
| `INTERMEDIATE` | 7-8 años | Estructura narrativa, vocabulario variado, fragmentos de ~120 palabras |
| `ADVANCED` | 9-10 años | Narrativa compleja, vocabulario rico, fragmentos de ~200 palabras |

## 3. Flujo Principal (Happy Path)

```mermaid
flowchart TD
    A[Padre/tutor abre la app] --> B[Crea perfil del niño]
    B --> C[Indica nombre, nivel y temas favoritos]
    C --> D[Selecciona tema para el cuento]
    D --> E[Backend genera cuento vía LLM]
    E --> F[Backend fragmenta el cuento según nivel]
    F --> G[Niño lee fragmento a fragmento]
    G --> H{¿Hay más fragmentos?}
    H -->|Sí| I[Botón 'Siguiente' → siguiente fragmento]
    I --> G
    H -->|No| J[Pantalla de celebración 🎉]
    J --> K[Puede volver al historial o crear otro cuento]
```

1. El padre/tutor abre la aplicación web
2. Crea un perfil para el niño (nombre, nivel de lectura, temas favoritos)
3. Selecciona un tema y opcionalmente escribe un prompt personalizado
4. El backend genera un cuento usando la API de Groq
5. El cuento se fragmenta automáticamente según el nivel de lectura
6. El niño lee fragmento por fragmento con controles simples
7. Al terminar, se muestra una pantalla de celebración
8. Puede ver su historial de cuentos y leer de nuevo

## 4. Requisitos Funcionales

| RF | Descripción | Prioridad |
|----|-------------|-----------|
| RF-01 | Crear perfil de lector con nombre, nivel de lectura y temas favoritos | Alta |
| RF-02 | Listar y consultar perfiles existentes | Alta |
| RF-03 | Eliminar perfil (con cascade de sus cuentos y fragmentos) | Media |
| RF-04 | Generar cuento personalizado usando LLM con nombre, nivel y tema del niño | Alta |
| RF-05 | Fragmentar automáticamente el cuento según el nivel de lectura | Alta |
| RF-06 | Lectura progresiva fragmento a fragmento con navegación anterior/siguiente | Alta |
| RF-07 | Visualizar progreso de lectura (barra de progreso) | Media |
| RF-08 | Listar historial de cuentos por perfil | Media |
| RF-09 | Consultar cuento completo con todos sus fragmentos | Media |
| RF-10 | Eliminar cuentos individuales | Baja |

## 5. Requisitos No Funcionales

| RNF | Descripción | Métrica |
|-----|-------------|---------|
| RNF-01 | Tiempo de respuesta de la API (sin contar LLM) < 500ms | P95 < 500ms |
| RNF-02 | La generación del cuento (LLM) debe completarse en < 30 segundos | P95 < 30s |
| RNF-03 | La UI debe ser responsive y funcional en móviles | Funcional en viewport ≥ 320px |
| RNF-04 | Los secretos (API keys) nunca se exponen al frontend | 0 secretos en código FE |
| RNF-05 | El dominio no debe tener dependencias de infraestructura | 0 imports de frameworks en domain/ |
| RNF-06 | El sistema debe arrancar en < 3 comandos | setup.bat + dev.bat |
| RNF-07 | Los tests deben ejecutarse sin requerir servicios externos | Solo SQLite en memoria y fakes |
| RNF-08 | La base de datos de desarrollo no requiere infraestructura adicional | SQLite como default |

## 6. Restricciones Técnicas

### Obligatorias (definidas por el experimento)

| Restricción | Impacto |
|-------------|---------|
| Frontend y backend estrictamente separados | Dos proyectos independientes con su propio build |
| Backend con arquitectura hexagonal | Puertos y adaptadores, dominio puro |
| Persistencia obligatoria con base de datos | No solo in-memory (excepto en tests) |
| LLM consumida solo desde backend | El frontend NO tiene acceso a API keys |
| Dominio no depende de infraestructura | `domain/` no importa FastAPI, SQLAlchemy, Groq, Pydantic |

### Stack propuesto

| Capa | Tecnología | Justificación |
|------|------------|---------------|
| **Backend** | Python 3.11+ / FastAPI | Async nativo, Pydantic integrado, OpenAPI automático |
| **ORM** | SQLAlchemy 2.0 | Soporte declarativo, SQLite→PostgreSQL sin cambios |
| **DB dev** | SQLite | Zero-config, archivo local |
| **DB prod** | PostgreSQL / Supabase | Solo cambiar DATABASE_URL |
| **LLM** | Groq (Llama 3.3 70B) | Inferencia ultrarrápida, excelente calidad para narrativa infantil, plan gratuito generoso |
| **Frontend** | React 19 / TypeScript / Vite | Ecosistema maduro, tipado estático, HMR rápido |
| **CSS** | Tailwind CSS v4 | Utility-first, rápido de iterar, responsivo |
| **Routing** | React Router v7 | Estándar de la comunidad React |

## 7. Alcance y Fuera de Alcance

### Dentro del alcance (MVP)

- Gestión de perfiles de lectores infantiles
- Generación de cuentos personalizados vía LLM
- Fragmentación automática por nivel de lectura
- Lectura progresiva con navegación y barra de progreso
- Historial de cuentos por perfil
- UI infantil con colores suaves y tipografía legible
- Scripts de ejecución para Windows (.bat)
- Persistencia con SQLite (desarrollo) y PostgreSQL (producción)

### Fuera del alcance

- Autenticación y autorización de usuarios
- Lectura en voz alta (text-to-speech)
- Ilustraciones generadas por IA
- Modo offline / PWA
- Internacionalización (i18n) — MVP solo en español
- Analytics de progreso de lectura
- Gamificación (logros, estrellas, etc.)
- Despliegue en la nube (CI/CD, Docker, Kubernetes)
- Aplicación móvil nativa
