# CuentoMágico — Benchmark de Evaluación

Criterios medibles para evaluar la calidad del proyecto en cada etapa.

## Escala de Puntuación

| Valor | Significado |
|-------|-------------|
| 0 | No cumple |
| 1 | Cumple parcialmente |
| 2 | Cumple completamente |

**Puntuación máxima: 60 puntos** (30 criterios × 2 puntos)

---

## 1. Compilación y Ejecución (10 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 1.1 | El backend inicia sin errores con `uvicorn app.main:app` | /2 |
| 1.2 | El frontend inicia sin errores con `npm run dev` | /2 |
| 1.3 | Los tests unitarios pasan con `pytest` | /2 |
| 1.4 | Los tests de integración pasan sin servicios externos | /2 |
| 1.5 | `scripts/setup.bat` + `scripts/dev.bat` levantan el proyecto completo | /2 |

## 2. Cumplimiento de Requisitos Funcionales (12 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 2.1 | Se puede crear un perfil de lector (nombre, nivel, temas) | /2 |
| 2.2 | Se puede generar un cuento personalizado con LLM | /2 |
| 2.3 | El cuento se fragmenta automáticamente según el nivel | /2 |
| 2.4 | Se puede leer fragmento a fragmento con navegación | /2 |
| 2.5 | Se muestra barra de progreso durante la lectura | /2 |
| 2.6 | Se puede consultar el historial de cuentos de un perfil | /2 |

## 3. Arquitectura Hexagonal (12 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 3.1 | Existe la capa `domain/` con entidades y value objects puros | /2 |
| 3.2 | Los puertos están definidos como interfaces (`Protocol`) | /2 |
| 3.3 | Los adaptadores implementan los puertos sin modificar el dominio | /2 |
| 3.4 | Los casos de uso están en `application/` y orquestan el dominio | /2 |
| 3.5 | La inyección de dependencias se hace en el composition root (`main.py`) | /2 |
| 3.6 | El dominio NO importa frameworks (FastAPI, SQLAlchemy, Pydantic, Groq) | /2 |

## 4. Separación de Capas (8 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 4.1 | Frontend y backend son proyectos independientes con su propio `README` | /2 |
| 4.2 | El frontend se comunica exclusivamente vía API REST | /2 |
| 4.3 | Las capas del backend siguen `infraestructura → aplicación → dominio` (nunca al revés) | /2 |
| 4.4 | Los modelos ORM están separados de las entidades de dominio | /2 |

## 5. Manejo Seguro de Secretos (8 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 5.1 | La API key del LLM se configura solo por variable de entorno en backend | /2 |
| 5.2 | Existe `.env.example` documentando las variables necesarias | /2 |
| 5.3 | El frontend NO tiene acceso a API keys ni credenciales de DB | /2 |
| 5.4 | No hay secretos hardcodeados en el código fuente | /2 |

## 6. Claridad Estructural (10 puntos)

| # | Criterio | Puntos |
|---|----------|--------|
| 6.1 | Existe documentación de arquitectura (diagramas, ADRs) | /2 |
| 6.2 | El contrato API está documentado en OpenAPI | /2 |
| 6.3 | El esquema de base de datos está documentado en `schema.sql` | /2 |
| 6.4 | Los nombres de archivos y carpetas son descriptivos y consistentes | /2 |
| 6.5 | Existe un README raíz con instrucciones claras para arrancar | /2 |

---

## Tabla Resumen

| Categoría | Criterios | Puntos máx. |
|-----------|-----------|-------------|
| Compilación y ejecución | 5 | 10 |
| Requisitos funcionales | 6 | 12 |
| Arquitectura hexagonal | 6 | 12 |
| Separación de capas | 4 | 8 |
| Manejo de secretos | 4 | 8 |
| Claridad estructural | 5 | 10 |
| **TOTAL** | **30** | **60** |

### Clasificación

| Rango | Calificación |
|-------|-------------|
| 54-60 | Excelente |
| 45-53 | Bueno |
| 36-44 | Aceptable |
| < 36 | Insuficiente |
