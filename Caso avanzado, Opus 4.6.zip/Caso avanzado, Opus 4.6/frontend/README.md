# CuentoMágico — Frontend

Interfaz web para cuentos infantiles personalizados con lectura progresiva.

## Stack Tecnológico

| Tecnología | Justificación |
|-----------|---------------|
| **React 19** | Librería de UI declarativa, ecosistema maduro |
| **TypeScript** | Tipado fuerte, previene errores en tiempo de compilación |
| **Vite** | Build ultrarrápido, HMR instantáneo, configuración mínima |
| **Tailwind CSS v4** | Utility-first, prototipado rápido, responsive nativo |
| **React Router v7** | Routing declarativo, estándar de facto |

## Pantallas

| Ruta | Pantalla | Descripción |
|------|----------|-------------|
| `/` | **Inicio** | Lista de perfiles de lectores + crear nuevo perfil |
| `/profiles/:id` | **Perfil** | Historial de cuentos + generar cuento nuevo |
| `/stories/:id` | **Lectura** | Lectura progresiva fragmento a fragmento |

## Características

- **Estilo infantil**: colores suaves (lavanda, crema, amarillo), tipografía grande, botones amplios
- **Lectura progresiva**: fragmentos revelados uno a uno con barra de progreso
- **Celebración**: pantalla de felicitación al terminar un cuento
- **Estados completos**: loading, error, vacío — todos manejados
- **Responsive**: funciona en escritorio, tablet y móvil
- **Sin secretos**: el frontend no conoce API keys ni proveedores LLM

## Instalación

```bash
cd frontend
npm install
```

## Configuración

Crear un archivo `.env` basado en el ejemplo:

```bash
cp .env.example .env
```

| Variable | Default | Descripción |
|----------|---------|-------------|
| `VITE_API_URL` | `http://localhost:8000` | URL base del backend |

## Ejecución

```bash
# Desarrollo (con hot reload)
npm run dev

# Build de producción
npm run build

# Preview del build
npm run preview
```

El servidor de desarrollo inicia en `http://localhost:5173`.

## Requisito: Backend

El frontend necesita el backend corriendo para funcionar:

```bash
cd ../backend
.venv\Scripts\Activate.ps1
uvicorn app.main:app --reload --port 8000
```

## Estructura

```
src/
├── api/
│   └── client.ts          # Cliente HTTP para el backend
├── types/
│   └── index.ts            # Tipos TS que espejean los schemas del API
├── components/
│   ├── Layout.tsx           # Header + wrapper
│   ├── LoadingSpinner.tsx   # Indicador de carga
│   ├── ErrorMessage.tsx     # Estado de error con retry
│   ├── EmptyState.tsx       # Estado vacío con acción
│   └── ProgressBar.tsx      # Barra de progreso de lectura
├── pages/
│   ├── HomePage.tsx         # Lista de perfiles + crear
│   ├── ProfilePage.tsx      # Historial + generar cuento
│   └── ReaderPage.tsx       # Lectura progresiva
├── App.tsx                  # Router principal
├── main.tsx                 # Entry point
└── index.css                # Tailwind + tema personalizado
```
