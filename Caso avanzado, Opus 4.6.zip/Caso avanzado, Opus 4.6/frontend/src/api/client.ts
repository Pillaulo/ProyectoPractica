import type { Profile, Story, StorySummary, Theme, ReadingLevel, ApiError } from '../types';

// En desarrollo usamos rutas relativas para que Vite proxy redirija al backend
const BASE_URL = import.meta.env.DEV ? '' : (import.meta.env.VITE_API_URL || 'http://localhost:8000');

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(path: string, options?: RequestInit): Promise<T> {
    let res: Response;
    try {
      res = await fetch(`${this.baseUrl}${path}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
      });
    } catch (e) {
      // Failed to fetch, conexión rechazada, CORS, etc.
      const msg = (e as Error).message?.toLowerCase().includes('fetch')
        ? 'No se pudo conectar con el servidor. ¿Está el backend ejecutándose en http://localhost:8000?'
        : 'Error de conexión con el servidor';
      throw { code: 'NETWORK_ERROR', message: msg };
    }

    if (!res.ok) {
      let error: ApiError;
      try {
        error = await res.json();
      } catch {
        error = { code: 'NETWORK_ERROR', message: 'Error de conexión con el servidor' };
      }
      throw error;
    }

    if (res.status === 204) return undefined as T;
    return res.json();
  }

  async healthCheck(): Promise<{ status: string; version: string }> {
    return this.request('/health');
  }

  async createProfile(data: {
    name: string;
    reading_level: ReadingLevel;
    favorite_themes: Theme[];
  }): Promise<Profile> {
    return this.request('/api/profiles', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async listProfiles(): Promise<Profile[]> {
    return this.request('/api/profiles');
  }

  async getProfile(id: string): Promise<Profile> {
    return this.request(`/api/profiles/${id}`);
  }

  async deleteProfile(id: string): Promise<void> {
    return this.request(`/api/profiles/${id}`, { method: 'DELETE' });
  }

  async generateStory(
    profileId: string,
    data: { theme: Theme; custom_prompt?: string },
  ): Promise<Story> {
    return this.request(`/api/profiles/${profileId}/stories`, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async listStories(profileId: string): Promise<StorySummary[]> {
    return this.request(`/api/profiles/${profileId}/stories`);
  }

  async getStory(id: string): Promise<Story> {
    return this.request(`/api/stories/${id}`);
  }

  async deleteStory(id: string): Promise<void> {
    return this.request(`/api/stories/${id}`, { method: 'DELETE' });
  }
}

export const api = new ApiClient(BASE_URL);
