export type ReadingLevel = 'INITIAL' | 'BASIC' | 'INTERMEDIATE' | 'ADVANCED';
export type Theme = 'ANIMALS' | 'FANTASY' | 'ADVENTURE' | 'NATURE' | 'SPACE' | 'FRIENDSHIP' | 'HUMOR';
export type StoryStatus = 'GENERATING' | 'READY' | 'ERROR';

export interface Profile {
  id: string;
  name: string;
  reading_level: ReadingLevel;
  favorite_themes: Theme[];
  created_at: string;
  updated_at: string;
}

export interface Fragment {
  id: string;
  order: number;
  content: string;
}

export interface Story {
  id: string;
  profile_id: string;
  title: string;
  theme: Theme;
  reading_level: ReadingLevel;
  status: StoryStatus;
  fragment_count: number;
  fragments: Fragment[];
  created_at: string;
}

export interface StorySummary {
  id: string;
  profile_id: string;
  title: string;
  theme: Theme;
  reading_level: ReadingLevel;
  status: StoryStatus;
  fragment_count: number;
  created_at: string;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export const THEME_LABELS: Record<Theme, string> = {
  ANIMALS: 'Animales',
  FANTASY: 'Fantasía',
  ADVENTURE: 'Aventuras',
  NATURE: 'Naturaleza',
  SPACE: 'Espacio',
  FRIENDSHIP: 'Amistad',
  HUMOR: 'Humor',
};

export const THEME_EMOJIS: Record<Theme, string> = {
  ANIMALS: '🐾',
  FANTASY: '🧙',
  ADVENTURE: '🗺️',
  NATURE: '🌿',
  SPACE: '🚀',
  FRIENDSHIP: '🤝',
  HUMOR: '😂',
};

export const LEVEL_LABELS: Record<ReadingLevel, string> = {
  INITIAL: 'Inicial (4–5 años)',
  BASIC: 'Básico (6–7 años)',
  INTERMEDIATE: 'Intermedio (8–9 años)',
  ADVANCED: 'Avanzado (10+ años)',
};

export const LEVEL_SHORT: Record<ReadingLevel, string> = {
  INITIAL: 'Inicial',
  BASIC: 'Básico',
  INTERMEDIATE: 'Intermedio',
  ADVANCED: 'Avanzado',
};
