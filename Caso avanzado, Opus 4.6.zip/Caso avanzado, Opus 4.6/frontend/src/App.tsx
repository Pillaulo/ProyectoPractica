import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import ReaderPage from './pages/ReaderPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/profiles/:id" element={<ProfilePage />} />
          <Route path="/stories/:id" element={<ReaderPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
