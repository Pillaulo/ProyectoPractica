interface Props {
  current: number;
  total: number;
}

export default function ProgressBar({ current, total }: Props) {
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;

  return (
    <div className="w-full">
      <div className="flex justify-between text-sm text-warm-gray/70 mb-1">
        <span>Fragmento {current} de {total}</span>
        <span>{pct}%</span>
      </div>
      <div className="w-full bg-lavender rounded-full h-3 overflow-hidden">
        <div
          className="bg-soft-purple h-full rounded-full transition-all duration-500 ease-out"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
