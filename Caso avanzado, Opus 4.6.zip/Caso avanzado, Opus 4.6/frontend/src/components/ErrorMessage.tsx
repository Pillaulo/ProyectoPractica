interface Props {
  message: string;
  onRetry?: () => void;
}

export default function ErrorMessage({ message, onRetry }: Props) {
  return (
    <div className="bg-red-50 border border-red-200 rounded-2xl p-6 text-center">
      <p className="text-3xl mb-3">😟</p>
      <p className="text-red-700 text-lg mb-4">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="bg-red-100 hover:bg-red-200 text-red-700 font-semibold px-6 py-2 rounded-xl transition"
        >
          Intentar de nuevo
        </button>
      )}
    </div>
  );
}
