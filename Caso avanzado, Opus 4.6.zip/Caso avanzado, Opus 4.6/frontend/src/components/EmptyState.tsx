interface Props {
  emoji: string;
  title: string;
  description: string;
  action?: { label: string; onClick: () => void };
}

export default function EmptyState({ emoji, title, description, action }: Props) {
  return (
    <div className="text-center py-16">
      <p className="text-5xl mb-4">{emoji}</p>
      <h3 className="text-xl font-bold text-warm-gray mb-2">{title}</h3>
      <p className="text-warm-gray/70 mb-6">{description}</p>
      {action && (
        <button
          onClick={action.onClick}
          className="bg-soft-purple hover:bg-soft-purple/90 text-white font-semibold px-8 py-3 rounded-2xl text-lg transition shadow-md hover:shadow-lg"
        >
          {action.label}
        </button>
      )}
    </div>
  );
}
