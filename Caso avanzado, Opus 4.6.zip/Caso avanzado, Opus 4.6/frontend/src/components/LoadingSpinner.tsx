interface Props {
  message?: string;
}

export default function LoadingSpinner({ message = 'Cargando...' }: Props) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-4">
      <div className="w-12 h-12 border-4 border-lavender border-t-soft-purple rounded-full animate-spin" />
      <p className="text-warm-gray text-lg">{message}</p>
    </div>
  );
}
