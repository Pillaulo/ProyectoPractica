import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client';
import type { Profile, StorySummary, Theme, ApiError } from '../types';
import { THEME_LABELS, THEME_EMOJIS, LEVEL_SHORT } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

const ALL_THEMES: Theme[] = ['ANIMALS', 'FANTASY', 'ADVENTURE', 'NATURE', 'SPACE', 'FRIENDSHIP', 'HUMOR'];

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [stories, setStories] = useState<StorySummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showGenerator, setShowGenerator] = useState(false);

  const fetchData = async () => {
    if (!id) return;
    setLoading(true);
    setError('');
    try {
      const [p, s] = await Promise.all([api.getProfile(id), api.listStories(id)]);
      setProfile(p);
      setStories(s);
    } catch (e) {
      setError((e as ApiError).message || 'Error al cargar el perfil');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [id]);

  if (loading) return <LoadingSpinner message="Cargando perfil..." />;
  if (error) return <ErrorMessage message={error} onRetry={fetchData} />;
  if (!profile) return <ErrorMessage message="Perfil no encontrado" />;

  return (
    <div>
      <Link to="/" className="text-soft-purple hover:underline text-sm mb-4 inline-block">← Volver a lectores</Link>

      <div className="bg-white rounded-2xl p-6 shadow-sm border border-lavender/50 mb-6">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-16 h-16 rounded-full bg-lavender flex items-center justify-center text-3xl font-bold text-soft-purple">
            {profile.name[0].toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-warm-gray">{profile.name}</h1>
            <span className="text-warm-gray/60">{LEVEL_SHORT[profile.reading_level]}</span>
          </div>
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {profile.favorite_themes.map((t) => (
            <span key={t} className="bg-lavender/50 text-warm-gray text-xs px-2.5 py-1 rounded-full">
              {THEME_EMOJIS[t]} {THEME_LABELS[t]}
            </span>
          ))}
        </div>
      </div>

      {!showGenerator && (
        <div className="text-center mb-8">
          <button
            onClick={() => setShowGenerator(true)}
            className="bg-soft-yellow hover:bg-soft-yellow/90 text-warm-gray font-bold px-8 py-4 rounded-2xl text-xl transition shadow-md hover:shadow-lg"
          >
            ✨ Crear un cuento nuevo
          </button>
        </div>
      )}

      {showGenerator && (
        <StoryGenerator
          profileId={profile.id}
          favoriteThemes={profile.favorite_themes}
          onGenerated={(storyId) => navigate(`/stories/${storyId}`)}
          onCancel={() => setShowGenerator(false)}
        />
      )}

      <h2 className="text-xl font-bold text-warm-gray mb-4">Historial de cuentos</h2>
      {stories.length === 0 ? (
        <EmptyState
          emoji="📚"
          title="Sin cuentos todavía"
          description="¡Genera el primer cuento para empezar a leer!"
        />
      ) : (
        <div className="grid gap-3">
          {stories.map((s) => (
            <Link
              key={s.id}
              to={`/stories/${s.id}`}
              className="bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition border border-lavender/50 flex items-center gap-4"
            >
              <span className="text-3xl">{THEME_EMOJIS[s.theme]}</span>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-warm-gray truncate">{s.title}</h3>
                <p className="text-sm text-warm-gray/60">
                  {s.fragment_count} fragmentos · {new Date(s.created_at).toLocaleDateString('es')}
                </p>
              </div>
              <span className="text-soft-purple text-sm font-semibold">Leer →</span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function StoryGenerator({
  profileId,
  favoriteThemes,
  onGenerated,
  onCancel,
}: {
  profileId: string;
  favoriteThemes: Theme[];
  onGenerated: (storyId: string) => void;
  onCancel: () => void;
}) {
  const [theme, setTheme] = useState<Theme>(favoriteThemes[0] || 'FANTASY');
  const [customPrompt, setCustomPrompt] = useState('');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');

  const handleGenerate = async () => {
    setGenerating(true);
    setError('');
    try {
      const story = await api.generateStory(profileId, {
        theme,
        custom_prompt: customPrompt.trim() || undefined,
      });
      onGenerated(story.id);
    } catch (e) {
      setError((e as ApiError).message || 'Error al generar el cuento');
      setGenerating(false);
    }
  };

  if (generating) {
    return (
      <div className="bg-white rounded-2xl p-8 shadow-md border border-lavender/50 mb-6 text-center">
        <div className="w-16 h-16 border-4 border-lavender border-t-soft-yellow rounded-full animate-spin mx-auto mb-4" />
        <p className="text-xl font-bold text-warm-gray mb-2">Creando tu cuento...</p>
        <p className="text-warm-gray/60">Esto puede tardar unos segundos</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl p-6 shadow-md border border-lavender/50 mb-6">
      <h3 className="text-lg font-bold text-soft-purple mb-4">¿De qué quieres el cuento?</h3>

      <div className="mb-4">
        <span className="text-warm-gray font-semibold text-sm block mb-2">Elige un tema</span>
        <div className="flex flex-wrap gap-2">
          {ALL_THEMES.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTheme(t)}
              className={`px-4 py-2.5 rounded-xl text-sm font-medium transition ${
                theme === t
                  ? 'bg-soft-purple text-white shadow-sm'
                  : 'bg-lavender/40 text-warm-gray hover:bg-lavender'
              }`}
            >
              {THEME_EMOJIS[t]} {THEME_LABELS[t]}
            </button>
          ))}
        </div>
      </div>

      <label className="block mb-5">
        <span className="text-warm-gray font-semibold text-sm">Algo especial para el cuento (opcional)</span>
        <input
          type="text"
          value={customPrompt}
          onChange={(e) => setCustomPrompt(e.target.value)}
          placeholder="Ej: un dragón que tiene miedo al fuego"
          maxLength={300}
          className="mt-1 w-full border border-lavender rounded-xl px-4 py-3 text-base focus:outline-none focus:ring-2 focus:ring-soft-purple/50"
        />
      </label>

      {error && <p className="text-red-500 text-sm mb-3">{error}</p>}

      <div className="flex gap-3">
        <button
          onClick={handleGenerate}
          className="flex-1 bg-soft-yellow hover:bg-soft-yellow/90 text-warm-gray font-bold py-3 rounded-xl text-lg transition shadow-sm"
        >
          ✨ Generar cuento
        </button>
        <button
          onClick={onCancel}
          className="px-6 py-3 rounded-xl text-warm-gray hover:bg-lavender/50 transition"
        >
          Cancelar
        </button>
      </div>
    </div>
  );
}
