import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api/client';
import type { Story, ApiError } from '../types';
import { THEME_EMOJIS } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import ProgressBar from '../components/ProgressBar';

export default function ReaderPage() {
  const { id } = useParams<{ id: string }>();
  const [story, setStory] = useState<Story | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchStory = async () => {
    if (!id) return;
    setLoading(true);
    setError('');
    try {
      const s = await api.getStory(id);
      setStory(s);
      setCurrentIndex(0);
    } catch (e) {
      setError((e as ApiError).message || 'Error al cargar el cuento');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStory(); }, [id]);

  if (loading) return <LoadingSpinner message="Cargando cuento..." />;
  if (error) return <ErrorMessage message={error} onRetry={fetchStory} />;
  if (!story || story.fragments.length === 0) {
    return <ErrorMessage message="Este cuento no tiene contenido" />;
  }

  const fragments = story.fragments;
  const isFirst = currentIndex === 0;
  const isLast = currentIndex === fragments.length - 1;
  const isFinished = currentIndex >= fragments.length;

  if (isFinished || (isLast && currentIndex === fragments.length)) {
    return <CelebrationScreen story={story} onRestart={() => setCurrentIndex(0)} />;
  }

  return (
    <div>
      <Link
        to={`/profiles/${story.profile_id}`}
        className="text-soft-purple hover:underline text-sm mb-4 inline-block"
      >
        ← Volver al perfil
      </Link>

      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-md border border-lavender/50 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <span className="text-2xl">{THEME_EMOJIS[story.theme]}</span>
          <h1 className="text-xl sm:text-2xl font-bold text-soft-purple">{story.title}</h1>
        </div>

        <ProgressBar current={currentIndex + 1} total={fragments.length} />

        <div className="my-8 min-h-[200px] flex items-center justify-center">
          <p
            key={currentIndex}
            className="text-xl sm:text-2xl leading-relaxed text-warm-gray text-center animate-fade-in"
          >
            {fragments[currentIndex].content}
          </p>
        </div>

        <div className="flex justify-between items-center gap-4">
          <button
            onClick={() => setCurrentIndex((i) => i - 1)}
            disabled={isFirst}
            className="flex items-center gap-2 px-6 py-3 rounded-2xl text-lg font-semibold transition
              disabled:opacity-30 disabled:cursor-not-allowed
              bg-lavender text-warm-gray hover:bg-lavender/70"
          >
            ← Anterior
          </button>

          {isLast ? (
            <button
              onClick={() => setCurrentIndex(fragments.length)}
              className="flex items-center gap-2 px-8 py-3 rounded-2xl text-lg font-bold transition
                bg-soft-green text-white hover:bg-soft-green/90 shadow-md"
            >
              ¡Terminé! 🎉
            </button>
          ) : (
            <button
              onClick={() => setCurrentIndex((i) => i + 1)}
              className="flex items-center gap-2 px-8 py-3 rounded-2xl text-lg font-bold transition
                bg-soft-purple text-white hover:bg-soft-purple/90 shadow-md"
            >
              Siguiente →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function CelebrationScreen({ story, onRestart }: { story: Story; onRestart: () => void }) {
  return (
    <div className="text-center py-8">
      <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-lg border border-soft-yellow/50 max-w-lg mx-auto">
        <p className="text-6xl mb-4 animate-bounce">🎉</p>
        <h2 className="text-2xl sm:text-3xl font-bold text-soft-purple mb-2">¡Felicidades!</h2>
        <p className="text-lg text-warm-gray mb-2">Has terminado de leer</p>
        <p className="text-xl font-bold text-warm-gray mb-8">"{story.title}"</p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={onRestart}
            className="bg-soft-yellow hover:bg-soft-yellow/90 text-warm-gray font-bold px-8 py-3 rounded-2xl text-lg transition shadow-md"
          >
            📖 Leer otra vez
          </button>
          <Link
            to={`/profiles/${story.profile_id}`}
            className="bg-soft-purple hover:bg-soft-purple/90 text-white font-bold px-8 py-3 rounded-2xl text-lg transition shadow-md"
          >
            ← Más cuentos
          </Link>
        </div>
      </div>
    </div>
  );
}
