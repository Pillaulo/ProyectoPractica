import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import type { Profile, ReadingLevel, Theme, ApiError } from '../types';
import { THEME_LABELS, THEME_EMOJIS, LEVEL_SHORT } from '../types';
import LoadingSpinner from '../components/LoadingSpinner';
import ErrorMessage from '../components/ErrorMessage';
import EmptyState from '../components/EmptyState';

const ALL_THEMES: Theme[] = ['ANIMALS', 'FANTASY', 'ADVENTURE', 'NATURE', 'SPACE', 'FRIENDSHIP', 'HUMOR'];
const ALL_LEVELS: ReadingLevel[] = ['INITIAL', 'BASIC', 'INTERMEDIATE', 'ADVANCED'];

export default function HomePage() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);

  const fetchProfiles = async () => {
    setLoading(true);
    setError('');
    try {
      setProfiles(await api.listProfiles());
    } catch (e) {
      setError((e as ApiError).message || 'No se pudieron cargar los perfiles');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchProfiles(); }, []);

  if (loading) return <LoadingSpinner message="Cargando perfiles..." />;
  if (error) return <ErrorMessage message={error} onRetry={fetchProfiles} />;

  return (
    <div>
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-soft-purple mb-2">¡Bienvenido a CuentoMágico!</h1>
        <p className="text-warm-gray/70 text-lg">Elige un lector o crea uno nuevo para empezar</p>
      </div>

      {profiles.length === 0 && !showForm ? (
        <EmptyState
          emoji="👋"
          title="No hay lectores todavía"
          description="Crea el primer perfil para generar cuentos personalizados"
          action={{ label: 'Crear lector', onClick: () => setShowForm(true) }}
        />
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            {profiles.map((p) => (
              <Link
                key={p.id}
                to={`/profiles/${p.id}`}
                className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition border border-lavender/50 flex flex-col gap-2"
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-lavender flex items-center justify-center text-2xl">
                    {p.name[0].toUpperCase()}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg text-warm-gray">{p.name}</h3>
                    <span className="text-sm text-warm-gray/60">{LEVEL_SHORT[p.reading_level]}</span>
                  </div>
                </div>
                <div className="flex gap-1.5 flex-wrap mt-1">
                  {p.favorite_themes.map((t) => (
                    <span key={t} className="bg-lavender/50 text-warm-gray text-xs px-2 py-1 rounded-full">
                      {THEME_EMOJIS[t]} {THEME_LABELS[t]}
                    </span>
                  ))}
                </div>
              </Link>
            ))}
          </div>

          {!showForm && (
            <div className="text-center">
              <button
                onClick={() => setShowForm(true)}
                className="bg-soft-purple hover:bg-soft-purple/90 text-white font-semibold px-8 py-3 rounded-2xl text-lg transition shadow-md hover:shadow-lg"
              >
                + Nuevo lector
              </button>
            </div>
          )}
        </>
      )}

      {showForm && (
        <CreateProfileForm
          onCreated={() => { setShowForm(false); fetchProfiles(); }}
          onCancel={() => setShowForm(false)}
        />
      )}
    </div>
  );
}

function CreateProfileForm({ onCreated, onCancel }: { onCreated: () => void; onCancel: () => void }) {
  const [name, setName] = useState('');
  const [level, setLevel] = useState<ReadingLevel>('BASIC');
  const [themes, setThemes] = useState<Theme[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const toggleTheme = (t: Theme) => {
    setThemes((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { setError('Escribe el nombre del niño'); return; }
    if (themes.length === 0) { setError('Elige al menos un tema'); return; }

    setSaving(true);
    setError('');
    try {
      await api.createProfile({ name: name.trim(), reading_level: level, favorite_themes: themes });
      onCreated();
    } catch (err) {
      setError((err as ApiError).message || 'Error al crear el perfil');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-md border border-lavender/50 max-w-md mx-auto mt-6">
      <h2 className="text-xl font-bold text-soft-purple mb-4">Nuevo lector</h2>

      <label className="block mb-4">
        <span className="text-warm-gray font-semibold text-sm">Nombre del niño</span>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej: Sofía"
          maxLength={100}
          className="mt-1 w-full border border-lavender rounded-xl px-4 py-3 text-lg focus:outline-none focus:ring-2 focus:ring-soft-purple/50"
        />
      </label>

      <label className="block mb-4">
        <span className="text-warm-gray font-semibold text-sm">Nivel de lectura</span>
        <select
          value={level}
          onChange={(e) => setLevel(e.target.value as ReadingLevel)}
          className="mt-1 w-full border border-lavender rounded-xl px-4 py-3 text-lg bg-white focus:outline-none focus:ring-2 focus:ring-soft-purple/50"
        >
          {ALL_LEVELS.map((l) => (
            <option key={l} value={l}>
              {l === 'INITIAL' && 'Inicial (4–5 años)'}
              {l === 'BASIC' && 'Básico (6–7 años)'}
              {l === 'INTERMEDIATE' && 'Intermedio (8–9 años)'}
              {l === 'ADVANCED' && 'Avanzado (10+ años)'}
            </option>
          ))}
        </select>
      </label>

      <fieldset className="mb-5">
        <legend className="text-warm-gray font-semibold text-sm mb-2">Temas favoritos</legend>
        <div className="flex flex-wrap gap-2">
          {ALL_THEMES.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => toggleTheme(t)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition ${
                themes.includes(t)
                  ? 'bg-soft-purple text-white shadow-sm'
                  : 'bg-lavender/40 text-warm-gray hover:bg-lavender'
              }`}
            >
              {THEME_EMOJIS[t]} {THEME_LABELS[t]}
            </button>
          ))}
        </div>
      </fieldset>

      {error && <p className="text-red-500 text-sm mb-3">{error}</p>}

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={saving}
          className="flex-1 bg-soft-purple hover:bg-soft-purple/90 text-white font-semibold py-3 rounded-xl text-lg transition disabled:opacity-50"
        >
          {saving ? 'Guardando...' : 'Crear lector'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-3 rounded-xl text-warm-gray hover:bg-lavender/50 transition"
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
